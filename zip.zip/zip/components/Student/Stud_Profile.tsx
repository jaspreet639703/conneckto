import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Text, Avatar, Button, Surface, Divider } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import BottomTabNavigator from '../common/BottomTabNavigator';
import Header from '../common/Header';
import { RootStackParamList } from '../../App';

interface StudentProfile {
  name: string;
  email: string;
  studentId: string;
  mobileNo: string;
  Address: string;
  Subscription: string;
}

const Stud_Profile: React.FC = () => {
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  const [profile, setProfile] = useState<StudentProfile>({
    name: 'Sandeep Kumar',
    email: 'sandeepkumar1234@gmail.com',
    studentId: 'STU2024001',
    mobileNo: '9982385483',
    Address: 'Jaroli, Rajasthan',
    Subscription: 'start date to end date',
  });

  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem('studentToken');
      await AsyncStorage.removeItem('username');
      navigation.reset({
        index: 0,
        routes: [{ name: 'StudentLogin' }],
      });
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  const handleRefer = () => {
    navigation.navigate('Refer');
  };

  return (
    <View style={styles.container}>
      <Header 
        title="Student Profile" 
        username={profile.name}
        showWelcome={true}
      />
      <ScrollView style={styles.content}>
        <Surface style={styles.profileHeader}>
          <Avatar.Text 
            size={80} 
            label={profile.name.split(' ').map(n => n[0]).join('')} 
            style={styles.avatar}
          />
          <Text style={styles.name}>{profile.name}</Text>
          <Text style={styles.email}>{profile.email}</Text>
          
          <Button 
            mode="contained"
            onPress={handleRefer}
            style={styles.referButton}
          >
            Refer a Friend
          </Button>
        </Surface>

        <Surface style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.label}>Student ID</Text>
            <Text style={styles.value}>{profile.studentId}</Text>
          </View>
          <Divider style={styles.divider} />
          
          <View style={styles.infoRow}>
            <Text style={styles.label}>Mobile Number</Text>
            <Text style={styles.value}>{profile.mobileNo}</Text>
          </View>
          <Divider style={styles.divider} />

          <View style={styles.infoRow}>
            <Text style={styles.label}>Address</Text>
            <Text style={styles.value}>{profile.Address}</Text>
          </View>
          <Divider style={styles.divider} />

          <View style={styles.infoRow}>
            <Text style={styles.label}>Subscription</Text>
            <Text style={styles.value}>{profile.Subscription}</Text>
          </View>
        </Surface>

        <Button 
          mode="contained" 
          onPress={handleLogout}
          style={styles.logoutButton}
          buttonColor="#d32f2f"
        >
          Logout
        </Button>
      </ScrollView>

      <BottomTabNavigator 
        activeTab="profile"
        onTabChange={(tab) => {
          if (tab === 'home') {
            navigation.navigate('StudentHome');
          } else if (tab === 'chat') {
            navigation.navigate('StudentChat');
          } else if (tab === 'booking') {
            navigation.navigate('BookSeat');
          } else if (tab === 'dashboard') {
            navigation.navigate('StudentDashboard');
          }
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  profileHeader: {
    padding: 24,
    alignItems: 'center',
    borderRadius: 12,
    margin: 16,
    elevation: 2,
  },
  avatar: {
    marginBottom: 16,
    backgroundColor: '#6200ee',
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  email: {
    fontSize: 16,
    color: '#666',
    marginBottom: 16,
  },
  referButton: {
    marginTop: 8,
    width: '100%',
  },
  infoCard: {
    padding: 16,
    borderRadius: 12,
    margin: 16,
    elevation: 2,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  label: {
    fontSize: 16,
    color: '#666',
  },
  value: {
    fontSize: 16,
    fontWeight: '500',
    flex: 1,
    textAlign: 'right',
    marginLeft: 16,
  },
  divider: {
    backgroundColor: '#e0e0e0',
  },
  logoutButton: {
    margin: 16,
  },
});

export default Stud_Profile;
