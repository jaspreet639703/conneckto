import RNHTMLtoPDF from 'react-native-html-to-pdf';
import { Platform, PermissionsAndroid } from 'react-native';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';

interface StudentCredential {
  name: string;
  studentId: string;
  password: string;
  email: string;
  mobile: string;
  subscriptionTime: string;
}

const generateHTML = (students: StudentCredential[]): string => {
  const tableRows = students.map(student => `
    <tr>
      <td>${student.name}</td>
      <td>${student.studentId}</td>
      <td>${student.password}</td>
      <td>${student.email}</td>
      <td>${student.mobile}</td>
      <td>${student.subscriptionTime}</td>
    </tr>
  `).join('');

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #4CAF50; color: white; }
          .header { text-align: center; margin-bottom: 30px; }
          .date { text-align: right; margin-bottom: 20px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Library Connekto - Student Credentials</h1>
        </div>
        <div class="date">
          Generated on: ${new Date().toLocaleDateString()}
        </div>
        <table>
          <thead>
            <tr>
              <th>Student Name</th>
              <th>Student ID</th>
              <th>Password</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Subscription</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
        </table>
      </body>
    </html>
  `;
};

export const generateStudentCredentialsPDF = async (students: StudentCredential[]): Promise<void> => {
  try {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE
      );
      if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
        throw new Error('Storage permission denied');
      }
    }

    const html = generateHTML(students);
    const options = {
      html,
      fileName: `StudentCredentials_${Date.now()}`,
      directory: 'Documents',
    };

    const file = await RNHTMLtoPDF.convert(options);
    
    if (file.filePath) {
      // For Expo, we need to use Sharing
      if (Platform.OS === 'ios') {
        await Sharing.shareAsync(file.filePath);
      } else {
        // For Android, the file is already saved in the Documents directory
        console.log('PDF saved to:', file.filePath);
      }
    }
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw error;
  }
};
