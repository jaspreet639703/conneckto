import React, { useState } from 'react';
import { View, ScrollView, TextInput as RNTextInput, StyleSheet, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { Surface, Text, IconButton, Portal, Modal, Button } from 'react-native-paper';
import * as ImagePicker from 'expo-image-picker';
import Header from '../common/Header';
import BottomTabNavigator from '../common/BottomTabNavigator';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../App';

interface Message {
  id: number;
  text: string;
  time: string;
  isUser: boolean;
  image?: string;
}

const Chat: React.FC = () => {
  const [message, setMessage] = useState('');
  const [showImageOptions, setShowImageOptions] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, text: "Hello! How can I help you with the library services today?", time: "10:00 AM", isUser: false },
    { id: 2, text: "Hi! I need help finding a book about machine learning.", time: "10:01 AM", isUser: true },
    { id: 3, text: "I can help you with that. Which specific topic in machine learning are you interested in?", time: "10:02 AM", isUser: false }
  ]);

  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();

  const handleSend = () => {
    if (message.trim()) {
      const newMessage: Message = {
        id: messages.length + 1,
        text: message,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isUser: true
      };
      setMessages([...messages, newMessage]);
      setMessage('');
    }
  };

  return (
    <View style={styles.container}>
      <Header title="Library Connekto" username="Online" />

      <ScrollView contentContainerStyle={styles.messagesContainer}>
        {messages.map((msg) => (
          <View key={msg.id} style={[styles.messageWrapper, msg.isUser ? styles.userMessageWrapper : styles.botMessageWrapper]}>
            <Surface style={[styles.messageBubble, msg.isUser ? styles.userMessage : styles.botMessage]}>
              {msg.image ? (
                <Image source={{ uri: msg.image }} style={styles.messageImage} resizeMode="cover" />
              ) : (
                <Text style={[styles.messageText, msg.isUser ? styles.userMessageText : styles.botMessageText]}>{msg.text}</Text>
              )}
              <Text style={[styles.timeText, msg.isUser ? styles.userTimeText : styles.botTimeText]}>{msg.time}</Text>
            </Surface>
          </View>
        ))}
      </ScrollView>

      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.inputContainer}>
        <Surface style={styles.inputWrapper}>
          <IconButton icon="image" size={24} onPress={() => setShowImageOptions(true)} />
          <RNTextInput
            style={styles.input}
            placeholder="Type your message..."
            value={message}
            onChangeText={setMessage}
            multiline
          />
          <IconButton icon="send" size={24} onPress={handleSend} disabled={!message.trim()} />
        </Surface>
      </KeyboardAvoidingView>

      <Portal>
        <Modal visible={showImageOptions} onDismiss={() => setShowImageOptions(false)} contentContainerStyle={styles.modal}>
          <Text style={styles.modalTitle}>Upload Image</Text>
          <Button mode="contained" onPress={() => setShowImageOptions(false)}>Choose from Gallery</Button>
          <Button mode="outlined" onPress={() => setShowImageOptions(false)}>Cancel</Button>
        </Modal>
      </Portal>

      <BottomTabNavigator 
        activeTab="chat" 
        onTabChange={(tab) => {
          if (tab === 'home') {
            navigation.navigate('StudentHome');
          } else if (tab === 'profile') {
            navigation.navigate('StudentProfile');
          } else if (tab === 'booking') {
            navigation.navigate('BookSeat');
          } else if (tab === 'dashboard') {
            navigation.navigate('StudentDashboard');
          }
        }} 
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  messagesContainer: { paddingVertical: 10, paddingHorizontal: 16 },
  messageWrapper: { marginBottom: 12, maxWidth: '80%' },
  userMessageWrapper: { alignSelf: 'flex-end' },
  botMessageWrapper: { alignSelf: 'flex-start' },
  messageBubble: { padding: 12, borderRadius: 16, elevation: 1 },
  userMessage: { backgroundColor: '#6200ee' },
  botMessage: { backgroundColor: 'white' },
  messageText: { fontSize: 16, marginBottom: 4 },
  messageImage: { width: 200, height: 150, borderRadius: 8 },
  userMessageText: { color: 'white' },
  botMessageText: { color: '#333' },
  timeText: { fontSize: 12, alignSelf: 'flex-end' },
  userTimeText: { color: 'rgba(255, 255, 255, 0.7)' },
  botTimeText: { color: 'rgba(0, 0, 0, 0.5)' },
  inputContainer: { padding: 10, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: '#e0e0e0' },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 24, backgroundColor: 'white', elevation: 2 },
  input: { flex: 1, marginHorizontal: 8, paddingVertical: 8, fontSize: 16, maxHeight: 100 },
  modal: { backgroundColor: 'white', padding: 20, margin: 20, borderRadius: 8 },
  modalTitle: { fontSize: 20, marginBottom: 20, textAlign: 'center' }
});

export default Chat;
