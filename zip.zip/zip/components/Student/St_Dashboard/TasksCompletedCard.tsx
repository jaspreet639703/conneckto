import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Surface, Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface TasksCompletedCardProps {
  completed: number;
  total: number;
}

const TasksCompletedCard: React.FC<TasksCompletedCardProps> = ({ completed, total }) => {
  return (
    <Surface style={styles.container}>
      <View style={styles.content}>
        <View>
          <Text style={styles.label}>Tasks Completed</Text>
          <Text style={styles.value}>{completed}/{total}</Text>
        </View>
        <MaterialCommunityIcons name="checkbox-marked-circle-outline" size={24} color="#0ea5e9" />
      </View>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f0f9ff',
    elevation: 2,
  },
  content: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  label: {
    fontSize: 12,
    color: '#075985',
    marginBottom: 4,
  },
  value: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0284c7',
  },
});

export default TasksCompletedCard;
