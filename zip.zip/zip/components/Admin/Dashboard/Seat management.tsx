import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  ScrollView,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import Header from '../../common/Header';

interface Student {
  id: string;
  name: string;
  mobile: string;
  address: string;
  libraryId: string;
  subscriptionStart: string;
  subscriptionEnd: string;
}

interface Seat {
  id: number;
  isOccupied: boolean;
  student?: Student;
}

const SeatManagementScreen: React.FC = () => {
  const navigation = useNavigation();
  const [showModal, setShowModal] = useState(false);
  const [selectedSeat, setSelectedSeat] = useState<Seat | null>(null);
  const totalSeats = 24;

  // Generate sample seats data
  const seats: Seat[] = Array.from({ length: totalSeats }, (_, index) => ({
    id: index + 1,
    isOccupied: Math.random() > 0.5,
    student: Math.random() > 0.5
      ? {
          id: `STU${(index + 1).toString().padStart(3, '0')}`,
          name: ['Emma Thompson', 'James Wilson', 'Sarah Parker', 'Michael Chen'][
            Math.floor(Math.random() * 4)
          ],
          mobile: `+1 ${Math.floor(Math.random() * 900 + 100)}-${Math.floor(
            Math.random() * 900 + 100
          )}-${Math.floor(Math.random() * 9000 + 1000)}`,
          address: [
            '123 Library Lane, Academic City',
            '456 Study Street, Knowledge Park',
            '789 Reading Road, Book Valley',
          ][Math.floor(Math.random() * 3)],
          libraryId: `LIB${(index + 1).toString().padStart(3, '0')}`,
          subscriptionStart: 'Mar 1, 2025',
          subscriptionEnd: 'Mar 31, 2025',
        }
      : undefined,
  }));

  const occupiedSeats = seats.filter((seat) => seat.isOccupied).length;
  const unoccupiedSeats = totalSeats - occupiedSeats;

  const handleSeatPress = (seat: Seat) => {
    setSelectedSeat(seat);
    setShowModal(true);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Header title="Library Seat Management" username="Admin" />

      <ScrollView style={styles.content}>
        {/* Statistics Cards */}
        <View style={styles.statsContainer}>
          <View style={[styles.statCard, { backgroundColor: '#3B82F6' }]}>
            <Text style={styles.statValue}>{totalSeats}</Text>
            <Text style={styles.statLabel}>Total Seats</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#10B981' }]}>
            <Text style={styles.statValue}>{occupiedSeats}</Text>
            <Text style={styles.statLabel}>Occupied</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#EF4444' }]}>
            <Text style={styles.statValue}>{unoccupiedSeats}</Text>
            <Text style={styles.statLabel}>Available</Text>
          </View>
        </View>

        {/* Seats Grid */}
        <View style={styles.seatsGrid}>
          {seats.map((seat) => (
            <TouchableOpacity
              key={seat.id}
              style={[
                styles.seatButton,
                {
                  backgroundColor: seat.isOccupied ? '#10B981' : '#EF4444',
                },
              ]}
              onPress={() => handleSeatPress(seat)}
            >
              <MaterialIcons name="event-seat" size={24} color="white" />
              <Text style={styles.seatText}>Seat {seat.id}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Seat Details Modal */}
      <Modal
        visible={showModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                Seat {selectedSeat?.id} Details
              </Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <MaterialIcons name="close" size={24} color="#666" />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalBody}>
              {selectedSeat?.isOccupied && selectedSeat?.student ? (
                <View style={styles.studentDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Library ID</Text>
                    <Text style={styles.detailValue}>
                      {selectedSeat.student.libraryId}
                    </Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Name</Text>
                    <Text style={styles.detailValue}>
                      {selectedSeat.student.name}
                    </Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Mobile</Text>
                    <Text style={styles.detailValue}>
                      {selectedSeat.student.mobile}
                    </Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Address</Text>
                    <Text style={styles.detailValue}>
                      {selectedSeat.student.address}
                    </Text>
                  </View>
                  <View style={styles.subscriptionRow}>
                    <Text style={styles.detailLabel}>Subscription Period</Text>
                    <View style={styles.subscriptionDates}>
                      <View style={styles.dateChip}>
                        <MaterialIcons name="calendar-today" size={16} color="#1D4ED8" />
                        <Text style={styles.dateText}>
                          {selectedSeat.student.subscriptionStart}
                        </Text>
                      </View>
                      <MaterialIcons name="arrow-forward" size={16} color="#666" />
                      <View style={styles.dateChip}>
                        <MaterialIcons name="event" size={16} color="#047857" />
                        <Text style={styles.dateText}>
                          {selectedSeat.student.subscriptionEnd}
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              ) : (
                <Text style={styles.emptyText}>
                  This seat is currently unoccupied
                </Text>
              )}
            </ScrollView>

            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setShowModal(false)}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    borderRadius: 8,
    padding: 12,
    marginHorizontal: 4,
  },
  statValue: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  statLabel: {
    color: 'white',
    fontSize: 12,
    marginTop: 4,
  },
  seatsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  seatButton: {
    width: '23%',
    aspectRatio: 1,
    borderRadius: 8,
    marginBottom: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  seatText: {
    color: 'white',
    fontSize: 12,
    marginTop: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 12,
    width: '100%',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalBody: {
    padding: 16,
  },
  studentDetails: {
    gap: 12,
  },
  detailRow: {
    marginBottom: 12,
  },
  detailLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: '500',
  },
  subscriptionRow: {
    marginTop: 8,
  },
  subscriptionDates: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  dateChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EFF6FF',
    padding: 8,
    borderRadius: 16,
    gap: 4,
  },
  dateText: {
    fontSize: 12,
    fontWeight: '500',
  },
  emptyText: {
    textAlign: 'center',
    color: '#666',
    fontSize: 16,
    padding: 24,
  },
  modalFooter: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  closeButton: {
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#374151',
    fontWeight: '500',
  },
});

export default SeatManagementScreen;
