import React, { useState, useEffect } from 'react';
import {
  View,
  Alert,
  ScrollView,
  Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { MaterialIcons } from '@expo/vector-icons';
import { 
  Text, 
  TextInput, 
  Button, 
  Surface, 
  useTheme, 
  IconButton,
  Checkbox,
  TouchableRipple 
} from 'react-native-paper';

interface AdminLoginProps {
  onLoginSuccess: () => void;
  onBack: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess, onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const theme = useTheme();

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const handleLogin = async () => {
    try {
      // Validate inputs
      if (!email || !password) {
        Alert.alert('Error', 'Please enter both email and password');
        return;
      }

      // Simulate API call delay
      await new Promise<void>((resolve) => setTimeout(resolve, 1500));

      // For demo purposes, check hardcoded credentials
      if (email === 'admin@library.com' && password === 'admin123') {
        onLoginSuccess();
      } else {
        Alert.alert('Error', 'Invalid credentials');
      }
    } catch (error) {
      Alert.alert('Error', 'An error occurred during login');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = () => {
    // Implement Google authentication logic
    Alert.alert('Info', 'Google login will be implemented here');
  };

  return (
    <Surface style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <StatusBar style="dark" />
      
      {/* Back Button */}
      <IconButton
        icon="arrow-left"
        size={24}
        onPress={onBack}
        style={{ position: 'absolute', top: 12, left: 4, zIndex: 10 }}
      />

      <ScrollView 
        contentContainerStyle={{ 
          flexGrow: 1,
          padding: 20,
        }}
      >
        <View style={{ 
          opacity: isVisible ? 1 : 0, 
          alignItems: 'center', 
          marginBottom: 40 
        }}>
          <Image
            source={{ uri: 'https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png' }}
            style={{ width: 120, height: 120, marginBottom: 20 }}
          />
          <Text variant="headlineMedium" style={{ marginBottom: 8 }}>
            Library Connekto
          </Text>
          <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>
            Welcome back! Please enter your details.
          </Text>
        </View>

        <Surface style={{ padding: 20, borderRadius: 12, elevation: 1 }}>
          {/* Email Input */}
          <TextInput
            label="Email"
            value={email}
            onChangeText={setEmail}
            mode="outlined"
            left={<TextInput.Icon icon="email" />}
            style={{ marginBottom: 16 }}
          />

          {/* Password Input */}
          <TextInput
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry={!showPassword}
            mode="outlined"
            left={<TextInput.Icon icon="lock" />}
            right={
              <TextInput.Icon
                icon={showPassword ? "eye-off" : "eye"}
                onPress={() => setShowPassword(!showPassword)}
              />
            }
            style={{ marginBottom: 16 }}
          />

          {/* Remember Me and Forgot Password */}
          <View style={{ 
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 24
          }}>
            <TouchableRipple onPress={() => setRememberMe(!rememberMe)}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Checkbox
                  status={rememberMe ? 'checked' : 'unchecked'}
                  onPress={() => setRememberMe(!rememberMe)}
                />
                <Text>Remember me</Text>
              </View>
            </TouchableRipple>
            
            <Button
              onPress={() => {}}
              mode="text"
            >
              Forgot Password?
            </Button>
          </View>

          {/* Login Button */}
          <Button
            mode="contained"
            onPress={handleLogin}
            style={{ paddingVertical: 6 }}
            loading={isLoading}
            disabled={isLoading}
          >
            {isLoading ? 'Signing in...' : 'Sign in'}
          </Button>

          {/* Divider */}
          <View style={{ 
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginTop: 24
          }}>
            <View style={{ flex: 1, height: 1, backgroundColor: theme.colors.onSurfaceVariant }} />
            <Text style={{ marginHorizontal: 8, color: theme.colors.onSurfaceVariant }}>
              Or continue with
            </Text>
            <View style={{ flex: 1, height: 1, backgroundColor: theme.colors.onSurfaceVariant }} />
          </View>

          {/* Google Sign In */}
          <Button
            mode="outlined"
            onPress={handleGoogleLogin}
            style={{ paddingVertical: 6, marginTop: 16 }}
          >
            <Image
              source={{ uri: 'https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png' }}
              style={{ width: 20, height: 20, marginRight: 8 }}
            />
            Sign in with Google
          </Button>
        </Surface>

        {/* Footer */}
        <View style={{ 
          alignItems: 'center', 
          marginBottom: 24, 
          marginTop: 24 
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <MaterialIcons name="security" size={16} color="#10B981" />
            <Text style={{ marginLeft: 8, color: theme.colors.onSurfaceVariant }}>
              Enterprise-grade security
            </Text>
          </View>
        </View>
      </ScrollView>
    </Surface>
  );
};

export default AdminLogin;
