import React from 'react';
import { View, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Text } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';

interface TabItem {
  value: string;
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  label: string;
  screen: string;
}

interface BottomTabNavigatorProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const BottomTabNavigator: React.FC<BottomTabNavigatorProps> = ({
  activeTab,
  onTabChange,
}) => {
  const navigation = useNavigation();
  
  const tabs: TabItem[] = [
    { value: 'home', icon: 'home', label: 'Home', screen: 'StudentHomeTab' },
    { value: 'booking', icon: 'seat', label: 'Book Seat', screen: 'BookSeatTab' },
    { value: 'dashboard', icon: 'view-dashboard', label: 'Dashboard', screen: 'StudentDashboardTab' },
    { value: 'chat', icon: 'chat', label: 'Chat', screen: 'StudentChatTab' },
    { value: 'profile', icon: 'account', label: 'Profile', screen: 'StudentProfileTab' },
  ];

  const handleTabPress = (tabValue: string, screen: string) => {
    onTabChange(tabValue);
    // @ts-ignore - Navigation typing issue
    navigation.navigate(screen);
  };

  return (
    <View style={styles.container}>
      {tabs.map((tab) => (
        <TouchableOpacity
          key={tab.value}
          style={styles.tab}
          onPress={() => handleTabPress(tab.value, tab.screen)}
        >
          <MaterialCommunityIcons
            name={tab.icon}
            size={24}
            color={activeTab === tab.value ? '#6366f1' : '#9ca3af'}
          />
          <Text
            style={[
              styles.tabLabel,
              { color: activeTab === tab.value ? '#6366f1' : '#9ca3af' },
            ]}
          >
            {tab.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: 'white',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabLabel: {
    fontSize: 12,
    marginTop: 4,
    fontWeight: '500',
  },
});

export default BottomTabNavigator;
