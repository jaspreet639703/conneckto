import React, { useState } from 'react';
import {
  View,
  ScrollView,
  Platform,
  Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { MaterialIcons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import {
  Surface,
  Text,
  TextInput,
  Button,
  IconButton,
  useTheme,
  Portal,
  Dialog,
  ActivityIndicator
} from 'react-native-paper';

interface AdminDetailsProps {
  onBack: () => void;
  onSave: (details: LibraryDetails) => void;
}

interface LibraryDetails {
  libraryName: string;
  mobileNo: string;
  address: string;
  totalSeats: string;
  referralCode?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

const AdminDetails: React.FC<AdminDetailsProps> = ({ onBack, onSave }) => {
  const [libraryName, setLibraryName] = useState('');
  const [mobileNo, setMobileNo] = useState('');
  const [address, setAddress] = useState('');
  const [totalSeats, setTotalSeats] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [coordinates, setCoordinates] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const theme = useTheme();

  const requestLocationPermission = async () => {
    setIsLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission denied', 'Location permission is required to get your coordinates.');
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      setCoordinates({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to get location. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = () => {
    if (!libraryName || !mobileNo || !address || !totalSeats) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (!coordinates) {
      Alert.alert('Error', 'Please get your location coordinates');
      return;
    }

    const details: LibraryDetails = {
      libraryName,
      mobileNo,
      address,
      totalSeats,
      referralCode: referralCode.trim() || undefined,
      coordinates,
    };

    onSave(details);
  };

  return (
    <Surface style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <StatusBar style="dark" />
      
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <IconButton
          icon="arrow-left"
          size={24}
          onPress={onBack}
          style={{ marginBottom: 20 }}
        />

        <Text variant="headlineMedium" style={{ marginBottom: 24 }}>
          Library Details
        </Text>

        <Surface style={{ padding: 20, borderRadius: 12, elevation: 1 }}>
          <TextInput
            label="Library Name"
            value={libraryName}
            onChangeText={setLibraryName}
            mode="outlined"
            style={{ marginBottom: 16 }}
          />

          <TextInput
            label="Mobile Number"
            value={mobileNo}
            onChangeText={setMobileNo}
            keyboardType="phone-pad"
            mode="outlined"
            style={{ marginBottom: 16 }}
          />

          <TextInput
            label="Address"
            value={address}
            onChangeText={setAddress}
            multiline
            numberOfLines={3}
            mode="outlined"
            style={{ marginBottom: 16 }}
          />

          <TextInput
            label="Total Seats"
            value={totalSeats}
            onChangeText={setTotalSeats}
            keyboardType="numeric"
            mode="outlined"
            style={{ marginBottom: 16 }}
          />

          <TextInput
            label="Referral Code (Optional)"
            value={referralCode}
            onChangeText={setReferralCode}
            mode="outlined"
            placeholder="Enter referral code if you have one"
            right={<TextInput.Icon icon="gift" />}
            style={{ marginBottom: 24 }}
          />

          <Button
            mode="outlined"
            onPress={requestLocationPermission}
            icon="map-marker"
            style={{ marginBottom: 24 }}
          >
            {coordinates ? 'Update Location' : 'Get Location'}
          </Button>

          {coordinates && (
            <Surface style={{ 
              padding: 12, 
              borderRadius: 8, 
              backgroundColor: theme.colors.surfaceVariant,
              marginBottom: 24
            }}>
              <Text variant="bodyMedium">
                Latitude: {coordinates.latitude.toFixed(6)}
              </Text>
              <Text variant="bodyMedium">
                Longitude: {coordinates.longitude.toFixed(6)}
              </Text>
            </Surface>
          )}

          <Button
            mode="contained"
            onPress={handleSave}
            style={{ paddingVertical: 6 }}
          >
            Save Details
          </Button>
        </Surface>
      </ScrollView>

      <Portal>
        <Dialog visible={isLoading}>
          <Dialog.Content>
            <View style={{ alignItems: 'center', padding: 20 }}>
              <ActivityIndicator size="large" />
              <Text style={{ marginTop: 16 }}>Getting location...</Text>
            </View>
          </Dialog.Content>
        </Dialog>
      </Portal>
    </Surface>
  );
};

export default AdminDetails;
