import React, { useState } from "react";
import { View, ScrollView, Share, StyleSheet, Dimensions, Image } from "react-native";
import { Text, Button, TextInput, Surface, IconButton, Snackbar } from "react-native-paper";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import Header from '../../common/Header';
import * as Clipboard from 'expo-clipboard';

const Refer: React.FC = () => {
  const [referralCode, setReferralCode] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showSuccess, setShowSuccess] = useState<boolean>(false);
  const [showError, setShowError] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [showCopied, setShowCopied] = useState<boolean>(false);

  const myReferralCode = "REF25MARCH";
  const rewardStats = {
    totalPoints: 300,
    totalReferrals: 3,
    recentReferrals: [
      { name: "Alexander Thompson", date: "2025-02-28", status: "Completed" },
      { name: "Emily Richardson", date: "2025-02-25", status: "Completed" },
      { name: "Michael Anderson", date: "2025-02-20", status: "Completed" },
    ],
  };

  const handleCopyCode = async () => {
    await Clipboard.setStringAsync(myReferralCode);
    setShowCopied(true);
    setTimeout(() => setShowCopied(false), 2000);
  };

  const handleShare = async () => {
    const shareText = `🎉 Hey fellow library owner! I'm using Library Conneckto to streamline my study library operations. It's a game-changer for managing everything from inventory to student records! Join me using my referral code: ${myReferralCode} and get special perks. Let's digitize our libraries together! 📚✨`;
    
    try {
      await Share.share({
        message: shareText,
        title: 'Join Library Conneckto'
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleReferral = () => {
    setIsLoading(true);
    setShowError(false);
    setShowSuccess(false);

    if (!referralCode.trim()) {
      setErrorMessage("Please enter a referral code");
      setShowError(true);
      setIsLoading(false);
      return;
    }

    setTimeout(() => {
      if (referralCode === "INVALID") {
        setErrorMessage("Invalid referral code");
        setShowError(true);
      } else {
        setShowSuccess(true);
      }
      setIsLoading(false);
    }, 1500);
  };

  return (
    <View style={styles.container}>
      <Header title="Refer Library Owners" />
      
      <ScrollView style={styles.content}>
        <Surface style={styles.heroSection}>
          <View style={styles.imageContainer}>
            <Image
              source={{ uri: "https://public.readdy.ai/ai/img_res/a813856c833064c9f390a136daf5ef8d.jpg" }}
              style={styles.libraryImage}
            />
            <MaterialCommunityIcons name="arrow-right" size={24} color="#6200ee" />
            <Image
              source={{ uri: "https://public.readdy.ai/ai/img_res/6d32af8cc1a8f05d742f23db4737ce9e.jpg" }}
              style={styles.libraryImage}
            />
          </View>
          <Text variant="headlineSmall" style={styles.title}>
            Transform Your Library Digital
          </Text>
          <Text variant="bodyMedium" style={styles.subtitle}>
            Help fellow library owners upgrade from traditional to digital operations.
          </Text>
          <Text variant="bodyMedium" style={styles.reward}>
            Both you and your referral get 100 points each!
          </Text>
        </Surface>

        <Surface style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.headerLeft}>
              <MaterialCommunityIcons name="share-variant" size={24} color="#6200ee" />
              <Text variant="titleMedium" style={styles.cardTitle}>Share Your Code</Text>
            </View>
            {showCopied && (
              <Text variant="bodySmall" style={styles.copiedText}>Copied!</Text>
            )}
          </View>

          <View style={styles.codeContainer}>
            <View>
              <Text variant="bodySmall">Your Referral Code</Text>
              <Text variant="headlineSmall" style={styles.referralCode}>{myReferralCode}</Text>
            </View>
            <Button
              mode="contained"
              onPress={handleCopyCode}
              icon="content-copy"
            >
              Copy
            </Button>
          </View>

          <Button
            mode="contained"
            onPress={handleShare}
            icon="share-variant"
            style={styles.shareButton}
          >
            Share Code
          </Button>
        </Surface>

        <Surface style={styles.card}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="gift" size={24} color="#6200ee" />
            <Text variant="titleMedium" style={styles.cardTitle}>How it works</Text>
          </View>

          <View style={styles.stepsList}>
            {[
              "Share Library Conneckto with other study library owners",
              "They register and start digitizing their library operations",
              "You get 100 points when someone uses your code",
              "They get 100 points when they register with your code"
            ].map((step, index) => (
              <View key={index} style={styles.step}>
                <MaterialCommunityIcons name="check-circle" size={20} color="#4CAF50" />
                <Text variant="bodyMedium" style={styles.stepText}>{step}</Text>
              </View>
            ))}
          </View>
        </Surface>

        <Surface style={styles.card}>
          <Text variant="titleMedium" style={styles.inputLabel}>Enter Referral Code</Text>
          <TextInput
            value={referralCode}
            onChangeText={setReferralCode}
            mode="outlined"
            placeholder="Enter code here"
            style={styles.input}
          />
          <Button
            mode="contained"
            onPress={handleReferral}
            loading={isLoading}
            style={styles.submitButton}
          >
            Submit Code
          </Button>
        </Surface>

        <Surface style={styles.card}>
          <Text variant="titleMedium" style={styles.sectionTitle}>Your Rewards</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <Text variant="displaySmall" style={styles.statValue}>{rewardStats.totalPoints}</Text>
              <Text variant="bodyMedium">Total Points</Text>
            </View>
            <View style={styles.statCard}>
              <Text variant="displaySmall" style={styles.statValue}>{rewardStats.totalReferrals}</Text>
              <Text variant="bodyMedium">Referrals</Text>
            </View>
          </View>

          <Text variant="titleMedium" style={[styles.sectionTitle, styles.activityTitle]}>
            Recent Activity
          </Text>
          <View style={styles.activityList}>
            {rewardStats.recentReferrals.map((referral, index) => (
              <View key={index} style={styles.activityItem}>
                <View>
                  <Text variant="bodyLarge">{referral.name}</Text>
                  <Text variant="bodySmall" style={styles.date}>{referral.date}</Text>
                </View>
                <Text variant="bodySmall" style={styles.status}>{referral.status}</Text>
              </View>
            ))}
          </View>
        </Surface>
      </ScrollView>

      <Snackbar
        visible={showError}
        onDismiss={() => setShowError(false)}
        duration={3000}
      >
        {errorMessage}
      </Snackbar>

      <Snackbar
        visible={showSuccess}
        onDismiss={() => setShowSuccess(false)}
        duration={3000}
      >
        Referral code applied successfully!
      </Snackbar>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  heroSection: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
  },
  imageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    gap: 16,
  },
  libraryImage: {
    width: 100,
    height: 100,
    borderRadius: 12,
  },
  title: {
    textAlign: 'center',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  subtitle: {
    textAlign: 'center',
    color: '#666666',
    marginBottom: 4,
  },
  reward: {
    textAlign: 'center',
    color: '#6200ee',
    fontWeight: '500',
  },
  card: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  cardTitle: {
    marginLeft: 12,
    color: '#1a1a1a',
  },
  copiedText: {
    color: '#4CAF50',
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  codeContainer: {
    backgroundColor: '#F3E5F5',
    padding: 12,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  referralCode: {
    color: '#6200ee',
    marginTop: 4,
  },
  shareButton: {
    marginTop: 8,
  },
  stepsList: {
    gap: 12,
  },
  step: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  stepText: {
    flex: 1,
    color: '#666666',
  },
  inputLabel: {
    marginBottom: 8,
  },
  input: {
    marginBottom: 16,
  },
  submitButton: {
    marginBottom: 8,
  },
  sectionTitle: {
    marginBottom: 16,
    color: '#1a1a1a',
  },
  activityTitle: {
    marginTop: 24,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#F3E5F5',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  statValue: {
    color: '#6200ee',
    marginBottom: 4,
  },
  activityList: {
    gap: 12,
  },
  activityItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  date: {
    color: '#666666',
    marginTop: 2,
  },
  status: {
    color: '#4CAF50',
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
});

export default Refer;
