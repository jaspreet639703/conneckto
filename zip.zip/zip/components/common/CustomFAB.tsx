import React from 'react';
import { StyleSheet } from 'react-native';
import { FAB, Portal } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';

interface CustomFABProps {
  open: boolean;
  onStateChange: (state: { open: boolean }) => void;
  onAddStudent: () => void;
  style?: any;
}

const CustomFAB: React.FC<CustomFABProps> = ({
  open,
  onStateChange,
  onAddStudent,
  style,
}) => {
  return (
    <Portal>
      <FAB
        label="Add Student"
        style={[styles.fab, style]}
        onPress={onAddStudent}
      />
    </Portal>
  );
};

const styles = StyleSheet.create({
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 80,
  },
});

export default CustomFAB;
