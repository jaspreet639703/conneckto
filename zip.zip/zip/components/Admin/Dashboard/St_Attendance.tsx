import React, { useState } from 'react';
import { View, ScrollView, StyleSheet, Platform } from 'react-native';
import { Text, DataTable, Searchbar, Button, Portal, FAB } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import Header from '../../common/Header';
import * as Print from 'expo-print';
import { shareAsync } from 'expo-sharing';

interface Student {
  id: string;
  name: string;
  status: 'Present' | 'Absent';
  checkInTime?: string;
  checkOutTime?: string;
}

const StudentAttendance: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(0);
  const [studentsPerPage] = useState(10);

  // Dummy data for demonstration
  const students: Student[] = [
    {
      id: '1',
      name: 'John Doe',
      status: 'Present',
      checkInTime: '09:30 AM',
      checkOutTime: '05:30 PM',
    },
    {
      id: '2',
      name: 'Jane Smith',
      status: 'Absent',
    },
    {
      id: '3',
      name: 'Michael Johnson',
      status: 'Present',
      checkInTime: '10:00 AM',
    },
    // Add more dummy data as needed
  ];

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const from = page * studentsPerPage;
  const to = Math.min((page + 1) * studentsPerPage, filteredStudents.length);

  const handleCheckIn = (studentId: string) => {
    const now = new Date();
    const currentTime = now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    // Implement check-in logic here
    console.log('Check in:', studentId, currentTime);
  };

  const handleCheckOut = (studentId: string) => {
    const now = new Date();
    const currentTime = now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    // Implement check-out logic here
    console.log('Check out:', studentId, currentTime);
  };

  const generatePDF = async () => {
    try {
      const currentDate = new Date().toLocaleDateString();
      const totalStudents = students.length;
      const presentStudents = students.filter(student => student.status === 'Present').length;
      const absentStudents = totalStudents - presentStudents;

      const htmlContent = `
        <html>
          <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
            <style>
              body { font-family: 'Helvetica'; padding: 20px; }
              h1 { color: #2196F3; text-align: center; }
              .stats { margin: 20px 0; padding: 10px; background: #f5f5f5; }
              table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #2196F3; color: white; }
              tr:nth-child(even) { background-color: #f9f9f9; }
            </style>
          </head>
          <body>
            <h1>Attendance Report - ${currentDate}</h1>
            <div class="stats">
              <p><strong>Total Students:</strong> ${totalStudents}</p>
              <p><strong>Present:</strong> ${presentStudents}</p>
              <p><strong>Absent:</strong> ${absentStudents}</p>
              <p><strong>Attendance Rate:</strong> ${((presentStudents / totalStudents) * 100).toFixed(1)}%</p>
            </div>
            <table>
              <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Status</th>
                <th>Check-in Time</th>
                <th>Check-out Time</th>
              </tr>
              ${students.map(student => `
                <tr>
                  <td>${student.id}</td>
                  <td>${student.name}</td>
                  <td>${student.status}</td>
                  <td>${student.checkInTime || '-'}</td>
                  <td>${student.checkOutTime || '-'}</td>
                </tr>
              `).join('')}
            </table>
          </body>
        </html>
      `;

      const { uri } = await Print.printToFileAsync({
        html: htmlContent,
        base64: false
      });
      
      await shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Header title="Student Attendance" username="Admin" />
      
      <View style={styles.content}>
        <View style={styles.statsContainer}>
          <View style={[styles.statCard, { backgroundColor: '#4CAF50' }]}>
            <Text style={styles.statValue}>
              {students.filter(s => s.status === 'Present').length}
            </Text>
            <Text style={styles.statLabel}>Present</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#F44336' }]}>
            <Text style={styles.statValue}>
              {students.filter(s => s.status === 'Absent').length}
            </Text>
            <Text style={styles.statLabel}>Absent</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#2196F3' }]}>
            <Text style={styles.statValue}>{students.length}</Text>
            <Text style={styles.statLabel}>Total</Text>
          </View>
        </View>

        <Searchbar
          placeholder="Search students..."
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchBar}
        />

        <ScrollView>
          <DataTable>
            <DataTable.Header>
              <DataTable.Title>Name</DataTable.Title>
              <DataTable.Title>Status</DataTable.Title>
              <DataTable.Title>Check In</DataTable.Title>
              <DataTable.Title>Check Out</DataTable.Title>
              <DataTable.Title>Actions</DataTable.Title>
            </DataTable.Header>

            {filteredStudents.slice(from, to).map((student) => (
              <DataTable.Row key={student.id}>
                <DataTable.Cell>{student.name}</DataTable.Cell>
                <DataTable.Cell>
                  <Text style={{ 
                    color: student.status === 'Present' ? '#4CAF50' : '#F44336'
                  }}>
                    {student.status}
                  </Text>
                </DataTable.Cell>
                <DataTable.Cell>{student.checkInTime || '-'}</DataTable.Cell>
                <DataTable.Cell>{student.checkOutTime || '-'}</DataTable.Cell>
                <DataTable.Cell style={styles.actionCell}>
                  {student.status === 'Absent' && (
                    <Button
                      mode="contained"
                      onPress={() => handleCheckIn(student.id)}
                      style={[styles.actionButton, { backgroundColor: '#4CAF50' }]}
                      labelStyle={styles.actionButtonLabel}
                    >
                      Check In
                    </Button>
                  )}
                  {student.status === 'Present' && !student.checkOutTime && (
                    <Button
                      mode="contained"
                      onPress={() => handleCheckOut(student.id)}
                      style={[styles.actionButton, { backgroundColor: '#F44336' }]}
                      labelStyle={styles.actionButtonLabel}
                    >
                      Check Out
                    </Button>
                  )}
                </DataTable.Cell>
              </DataTable.Row>
            ))}

            <DataTable.Pagination
              page={page}
              numberOfPages={Math.ceil(filteredStudents.length / studentsPerPage)}
              onPageChange={setPage}
              label={`${from + 1}-${to} of ${filteredStudents.length}`}
            />
          </DataTable>
        </ScrollView>
      </View>

      <Portal>
        <FAB
          icon="file-download"
          style={styles.fab}
          onPress={generatePDF}
        />
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    borderRadius: 8,
    padding: 16,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  statValue: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  statLabel: {
    color: 'white',
    fontSize: 14,
    marginTop: 4,
  },
  searchBar: {
    marginBottom: 16,
    elevation: 2,
  },
  actionCell: {
    flex: 1,
    justifyContent: 'center',
  },
  actionButton: {
    marginHorizontal: 4,
    paddingHorizontal: 8,
  },
  actionButtonLabel: {
    fontSize: 12,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 70, // Increased to avoid overlap with bottom navigation
  },
});

export default StudentAttendance;
