import React, { useState } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Text, Button } from 'react-native-paper';
import { useNavigation, NavigationProp } from '@react-navigation/native';
import Header from '../../common/Header';
import DashboardCard from './DashboardCard';
import ActionButton from './ActionButton';
import RecentActivity from './RecentActivity';
import StudentRegistrationModal from '../StudentRegistration/StudentRegistrationModal';
import CustomFAB from '../../common/CustomFAB';

type RootStackParamList = {
  MainDashboard: undefined;
  StudentManagement: undefined;
  SeatManagement: undefined;
  StudentAttendance: undefined;
  Analytics: undefined;
};

type NavigationProps = NavigationProp<RootStackParamList>;

interface Activity {
  id: number;
  type: string;
  name: string;
  details: string;
  time: string;
  status: 'completed' | 'pending' | 'cancelled';
}

const Dashboard: React.FC = () => {
  const navigation = useNavigation<NavigationProps>();
  const [fabOpen, setFabOpen] = useState(false);
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const totalLibrarySeats = 450; // You can make this dynamic based on your requirements

  const currentDate = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const activities: Activity[] = [
    {
      id: 1,
      type: 'Check In',
      name: 'Emily Parker',
      details: 'Seat A-12',
      time: '10 minutes ago',
      status: 'completed'
    },
    {
      id: 2,
      type: 'New Registration',
      name: 'Michael Chen',
      details: '3 Months Plan',
      time: '25 minutes ago',
      status: 'pending'
    },
    {
      id: 3,
      type: 'Subscription Renewal',
      name: 'Sarah Wilson',
      details: '6 Months Plan',
      time: '1 hour ago',
      status: 'completed'
    }
  ];

  const handleStudentRegistration = (studentData: any) => {
    // TODO: Implement API call to save student data
    console.log('Student registration data:', studentData);
    // After successful registration:
    setShowRegistrationModal(false);
    // Show success message or update UI as needed
  };

  return (
    <View style={styles.container}>
      <Header title="Library Connekto" username="Admin" />
      <ScrollView 
        style={styles.content}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.date}>{currentDate}</Text>

        <View style={styles.statsContainer}>
          <DashboardCard
            title="Today"
            value="386/450"
            subtitle="Occupied/Total Seats"
            backgroundColor="#6200ee"
          />
          <DashboardCard
            title="Today"
            value="247/547"
            subtitle="Present/Registered"
            backgroundColor="#00C853"
          />
        </View>

        <View style={styles.actionsContainer}>
          <View style={styles.actionRow}>
            <ActionButton
              title="Student Management"
              icon="school"
              backgroundColor="#E8EAF6"
              onPress={() => navigation.navigate('StudentManagement')}
            />
            <ActionButton
              title="Attendance"
              icon="event-available"
              backgroundColor="#E0F2F1"
              onPress={() => navigation.navigate('StudentAttendance')}
            />
          </View>
          <View style={styles.actionRow}>
            <ActionButton
              title="Analytics"
              icon="analytics"
              backgroundColor="#FFF8E1"
              onPress={() => navigation.navigate('Analytics')}
            />
            <ActionButton
              title="Seat Manager"
              icon="event-seat"
              backgroundColor="#FCE4EC"
              onPress={() => navigation.navigate('SeatManagement')}
            />
          </View>
        </View>

        <View style={styles.recentActivitiesHeader}>
          <Text style={styles.sectionTitle}>Recent Activities</Text>
          <Button 
            mode="text" 
            textColor="#6200ee"
            onPress={() => {}}
          >
            View All
          </Button>
        </View>

        {activities.map(activity => (
          <RecentActivity key={activity.id} activity={activity} />
        ))}
      </ScrollView>

      {/* Replace FAB.Group with CustomFAB */}
      <CustomFAB
        open={fabOpen}
        onStateChange={({ open }) => setFabOpen(open)}
        onAddStudent={() => setShowRegistrationModal(true)}
      />

      <StudentRegistrationModal
        visible={showRegistrationModal}
        onDismiss={() => setShowRegistrationModal(false)}
        onSubmit={handleStudentRegistration}
        totalLibrarySeats={totalLibrarySeats}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 80, // Add padding for FAB
  },
  date: {
    fontSize: 14,
    color: '#666',
    marginBottom: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    marginHorizontal: -8,
  },
  actionsContainer: {
    marginTop: 24,
  },
  actionRow: {
    flexDirection: 'row',
    marginHorizontal: -8,
  },
  recentActivitiesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 8,
    paddingHorizontal: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default Dashboard;
