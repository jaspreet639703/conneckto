import React, { useState } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Text, DataTable, Searchbar, Surface, Button } from 'react-native-paper';
import Header from '../../common/Header';
import CustomFAB from '../../common/CustomFAB';
import StudentRegistrationModal from '../StudentRegistration/StudentRegistrationModal';
import { MaterialIcons } from '@expo/vector-icons';

interface Student {
  id: string;
  name: string;
  seatNo: string;
  status: 'Present' | 'Absent';
  subscriptionStatus: 'Active' | 'Expired';
  lastVisit: string;
}

const StudentManagement: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(0);
  const [studentsPerPage] = useState(10);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const totalLibrarySeats = 450; // You can make this dynamic based on your requirements

  const handleStudentRegistration = (studentData: any) => {
    // TODO: Implement API call to save student data
    console.log('Student registration data:', studentData);
    setShowRegistrationModal(false);
  };

  // Dummy data for demonstration
  const students: Student[] = [
    {
      id: '1',
      name: 'John Doe',
      seatNo: 'A-12',
      status: 'Present',
      subscriptionStatus: 'Active',
      lastVisit: '2025-03-01',
    },
    {
      id: '2',
      name: 'Jane Smith',
      seatNo: 'B-05',
      status: 'Absent',
      subscriptionStatus: 'Active',
      lastVisit: '2025-02-28',
    },
    // Add more dummy data as needed
  ];

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const from = page * studentsPerPage;
  const to = Math.min((page + 1) * studentsPerPage, filteredStudents.length);

  return (
    <View style={styles.container}>
      <Header title="Student Management" username="Admin" />
      
      <View style={styles.content}>
        <Searchbar
          placeholder="Search students..."
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchBar}
        />

        <ScrollView>
          <DataTable>
            <DataTable.Header>
              <DataTable.Title>Name</DataTable.Title>
              <DataTable.Title>Seat No.</DataTable.Title>
              <DataTable.Title>Status</DataTable.Title>
              <DataTable.Title>Subscription</DataTable.Title>
              <DataTable.Title>Actions</DataTable.Title>
            </DataTable.Header>

            {filteredStudents.slice(from, to).map((student) => (
              <DataTable.Row key={student.id}>
                <DataTable.Cell>{student.name}</DataTable.Cell>
                <DataTable.Cell>{student.seatNo}</DataTable.Cell>
                <DataTable.Cell>
                  <Text style={{ 
                    color: student.status === 'Present' ? '#4CAF50' : '#F44336'
                  }}>
                    {student.status}
                  </Text>
                </DataTable.Cell>
                <DataTable.Cell>
                  <Text style={{ 
                    color: student.subscriptionStatus === 'Active' ? '#4CAF50' : '#F44336'
                  }}>
                    {student.subscriptionStatus}
                  </Text>
                </DataTable.Cell>
                <DataTable.Cell>
                  <Button
                    mode="text"
                    onPress={() => {
                      setSelectedStudent(student);
                      setShowDetailsModal(true);
                    }}
                  >
                    View
                  </Button>
                </DataTable.Cell>
              </DataTable.Row>
            ))}

            <DataTable.Pagination
              page={page}
              numberOfPages={Math.ceil(filteredStudents.length / studentsPerPage)}
              onPageChange={setPage}
              label={`${from + 1}-${to} of ${filteredStudents.length}`}
            />
          </DataTable>
        </ScrollView>
      </View>

      {/* Student Details Modal */}
      {showDetailsModal && selectedStudent && (
        <Surface style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Student Details</Text>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Name:</Text>
              <Text style={styles.detailValue}>{selectedStudent.name}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Seat Number:</Text>
              <Text style={styles.detailValue}>{selectedStudent.seatNo}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Status:</Text>
              <Text style={[
                styles.detailValue,
                { color: selectedStudent.status === 'Present' ? '#4CAF50' : '#F44336' }
              ]}>
                {selectedStudent.status}
              </Text>
            </View>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Subscription:</Text>
              <Text style={[
                styles.detailValue,
                { color: selectedStudent.subscriptionStatus === 'Active' ? '#4CAF50' : '#F44336' }
              ]}>
                {selectedStudent.subscriptionStatus}
              </Text>
            </View>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Last Visit:</Text>
              <Text style={styles.detailValue}>{selectedStudent.lastVisit}</Text>
            </View>

            <View style={styles.modalButtons}>
              <Button 
                mode="outlined"
                onPress={() => setShowDetailsModal(false)}
                style={styles.modalButton}
              >
                Close
              </Button>
              <Button 
                mode="contained"
                onPress={() => {
                  // Handle edit action
                  setShowDetailsModal(false);
                }}
                style={styles.modalButton}
              >
                Edit
              </Button>
            </View>
          </View>
        </Surface>
      )}

      <CustomFAB
        open={fabOpen}
        onStateChange={({ open }) => setFabOpen(open)}
        onAddStudent={() => setShowRegistrationModal(true)}
      />

      <StudentRegistrationModal
        visible={showRegistrationModal}
        onDismiss={() => setShowRegistrationModal(false)}
        onSubmit={handleStudentRegistration}
        totalLibrarySeats={totalLibrarySeats}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  searchBar: {
    marginBottom: 16,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    width: '90%',
    maxWidth: 500,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  detailLabel: {
    fontWeight: 'bold',
    width: 120,
  },
  detailValue: {
    flex: 1,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 20,
  },
  modalButton: {
    marginLeft: 10,
  },
});

export default StudentManagement;