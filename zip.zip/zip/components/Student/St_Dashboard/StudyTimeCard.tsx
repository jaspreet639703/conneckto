import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Surface, Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface StudyTimeCardProps {
  hours: number;
}

const StudyTimeCard: React.FC<StudyTimeCardProps> = ({ hours }) => {
  return (
    <Surface style={styles.container}>
      <View style={styles.content}>
        <View>
          <Text style={styles.label}>Today's Study Time</Text>
          <Text style={styles.value}>{hours} hrs</Text>
        </View>
        <MaterialCommunityIcons name="clock-outline" size={24} color="#a855f7" />
      </View>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f5f3ff',
    elevation: 2,
  },
  content: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  label: {
    fontSize: 12,
    color: '#6b21a8',
    marginBottom: 4,
  },
  value: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#7c3aed',
  },
});

export default StudyTimeCard;
