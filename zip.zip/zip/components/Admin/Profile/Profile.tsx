import React, { useState, useContext } from "react";
import { View, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { Text, Button, TextInput, Surface, useTheme } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Header from '../../common/Header';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../App';
import { AuthContext } from '../../../App';

interface LibraryProfile {
  name: string;
  libraryId: string;
  contact: string;
  email: string;
  totalSeats: number;
  address: string;
}

const Profile: React.FC = () => {
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<LibraryProfile>({
    name: "Central Research Library",
    libraryId: "LIB-2025-0223",
    contact: "+1 (555) 123-4567",
    email: "central.library@connekto.edu",
    totalSeats: 450,
    address: "789 Knowledge Avenue, Academic District, Cambridge, MA 02138",
  });
  const [editedProfile, setEditedProfile] = useState<LibraryProfile>(profile);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const { setSelectedRole, setIsLoggedIn, setShowHome } = useContext(AuthContext);

  const handleEdit = () => {
    setIsEditing(true);
    setEditedProfile(profile);
  };

  const handleSave = () => {
    setProfile(editedProfile);
    setIsEditing(false);
    setShowSuccessToast(true);
    setTimeout(() => setShowSuccessToast(false), 3000);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditedProfile(profile);
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.clear();
      setSelectedRole(null);
      setIsLoggedIn(false);
      setShowHome(false);
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f5f5f5' }}>
      <Header title="Profile" username="Sarah Anderson" />
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: 80 }}
        showsVerticalScrollIndicator={false}
        bounces={true}
      >
        <Surface style={{ margin: 16, borderRadius: 12, elevation: 4 }}>
          <View style={{ padding: 16 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ 
                width: 80, 
                height: 80, 
                borderRadius: 40, 
                backgroundColor: '#6200ee',
                justifyContent: 'center',
                alignItems: 'center' 
              }}>
                <MaterialCommunityIcons name="account-tie" size={32} color="white" />
              </View>
              <View style={{ marginLeft: 16, flex: 1 }}>
                <Text variant="titleLarge">Sarah Anderson</Text>
                <Text variant="bodyMedium" style={{ color: '#666' }}>Library Administrator</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
                  <MaterialCommunityIcons name="clock" size={14} color="#666" />
                  <Text variant="bodySmall" style={{ marginLeft: 8, color: '#666' }}>
                    Active now • Member since Feb 2025
                  </Text>
                </View>
              </View>
            </View>
            
            <TouchableOpacity onPress={() => navigation.navigate('Refer')} style={{ marginTop: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#6200ee', padding: 8, borderRadius: 8 }}>
              <MaterialCommunityIcons name="share-variant" size={24} color="white" />
              <Text style={{ color: 'white', marginLeft: 8 }}>Refer Library Owners</Text>
            </TouchableOpacity>
          </View>
        </Surface>

        <Surface style={{ margin: 16, borderRadius: 12, elevation: 4 }}>
          <View style={{ padding: 16 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <Text variant="titleLarge">Profile Details</Text>
              {!isEditing ? (
                <Button 
                  mode="contained-tonal" 
                  onPress={handleEdit}
                  icon="pencil"
                >
                  Edit
                </Button>
              ) : (
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <Button 
                    mode="contained" 
                    onPress={handleSave}
                  >
                    Save
                  </Button>
                  <Button 
                    mode="outlined" 
                    onPress={handleCancel}
                  >
                    Cancel
                  </Button>
                </View>
              )}
            </View>

            <View style={{ gap: 16 }}>
              <View>
                <Text variant="bodySmall" style={{ color: '#666' }}>Library Name</Text>
                {isEditing ? (
                  <TextInput
                    value={editedProfile.name}
                    onChangeText={(text) => setEditedProfile({ ...editedProfile, name: text })}
                    mode="outlined"
                    style={{ marginTop: 4 }}
                  />
                ) : (
                  <Text variant="bodyLarge">{profile.name}</Text>
                )}
              </View>

              <View>
                <Text variant="bodySmall" style={{ color: '#666' }}>Library ID</Text>
                <Text variant="bodyLarge">{profile.libraryId}</Text>
              </View>

              <View>
                <Text variant="bodySmall" style={{ color: '#666' }}>Contact Number</Text>
                {isEditing ? (
                  <TextInput
                    value={editedProfile.contact}
                    onChangeText={(text) => setEditedProfile({ ...editedProfile, contact: text })}
                    mode="outlined"
                    style={{ marginTop: 4 }}
                    keyboardType="phone-pad"
                  />
                ) : (
                  <Text variant="bodyLarge">{profile.contact}</Text>
                )}
              </View>

              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons name="email" size={24} color="#666" />
                <Text style={{ marginLeft: 8, color: '#666' }}>{profile.email}</Text>
              </View>

              <View>
                <Text variant="bodySmall" style={{ color: '#666' }}>Total Seats</Text>
                {isEditing ? (
                  <TextInput
                    value={editedProfile.totalSeats.toString()}
                    onChangeText={(text) => setEditedProfile({ ...editedProfile, totalSeats: parseInt(text) || 0 })}
                    mode="outlined"
                    style={{ marginTop: 4 }}
                    keyboardType="numeric"
                  />
                ) : (
                  <Text variant="bodyLarge">{profile.totalSeats}</Text>
                )}
              </View>

              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons name="map-marker" size={24} color="#666" />
                <Text style={{ marginLeft: 8, color: '#666' }}>{profile.address}</Text>
              </View>
            </View>
          </View>
        </Surface>

        <View style={{ margin: 16, alignItems: 'center', marginBottom: 32 }}>
          <Button 
            mode="contained" 
            onPress={handleLogout} 
            style={{ backgroundColor: '#d32f2f', width: '100%', paddingVertical: 8 }}
          >
            Logout
          </Button>
        </View>

        {showSuccessToast && (
          <View style={{ position: 'absolute', bottom: 20, left: 0, right: 0, justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ backgroundColor: '#34C759', padding: 16, borderRadius: 12, elevation: 4 }}>
              <MaterialCommunityIcons name="check-circle" size={20} color="white" />
              <Text variant="bodyMedium" style={{ color: 'white', marginLeft: 8 }}>Profile updated successfully</Text>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

export default Profile;
