import React, { useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Modal, Portal, Text, TextInput, Button, SegmentedButtons, Snackbar, List, Dialog, Switch } from 'react-native-paper';
import * as DocumentPicker from 'expo-document-picker';
import * as XLSX from 'xlsx';
import { generateStudentCredentialsPDF } from '../../../utils/pdfGenerator';
import { getNextStudentId } from '../../../services/counterService';

interface StudentRegistrationModalProps {
  visible: boolean;
  onDismiss: () => void;
  onSubmit: (studentData: any) => void;
  totalLibrarySeats: number;
}

interface StudentCredentials {
  studentId: string;
  password: string;
  name: string;
}

const generatePassword = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let password = '';
  for (let i = 0; i < 8; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
};

const StudentRegistrationModal: React.FC<StudentRegistrationModalProps> = ({
  visible,
  onDismiss,
  onSubmit,
  totalLibrarySeats,
}) => {
  const [registrationType, setRegistrationType] = useState('single');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [subscriptionTime, setSubscriptionTime] = useState('1 Month');
  const [isShiftStudent, setIsShiftStudent] = useState(false);
  const [shiftTime, setShiftTime] = useState('');
  const [subscriptionMenuVisible, setSubscriptionMenuVisible] = useState(false);
  const [snackbarVisible, setSnackbarVisible] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [credentialsDialog, setCredentialsDialog] = useState<{
    visible: boolean;
    credentials: StudentCredentials | StudentCredentials[];
  }>({
    visible: false,
    credentials: [],
  });

  const subscriptionOptions = [
    { label: '1 Month', value: '1 Month' },
    { label: '3 Months', value: '3 Months' },
    { label: '6 Months', value: '6 Months' },
    { label: '1 Year', value: '1 Year' },
  ];

  const handleSingleSubmit = () => {
    if (!name || !mobile || !email || !address || !subscriptionTime) {
      alert('Please fill all the fields');
      return;
    }

    if (isShiftStudent && !shiftTime) {
      alert('Please enter shift time');
      return;
    }

    const studentId = getNextStudentId();
    const password = generatePassword();

    const studentData = {
      name,
      mobile,
      email,
      address,
      subscriptionTime,
      studentId,
      password,
      isShiftStudent,
      shiftTime: isShiftStudent ? shiftTime : null,
    };

    onSubmit(studentData);
    setCredentialsDialog({
      visible: true,
      credentials: { studentId, password, name },
    });
    resetForm();
  };

  const handleBulkUpload = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/csv'],
      });

      if (result.assets && result.assets.length > 0) {
        const file = result.assets[0];
        const response = await fetch(file.uri);
        const blob = await response.blob();
        const reader = new FileReader();

        reader.onload = async (e) => {
          try {
            const data = e.target?.result;
            const workbook = XLSX.read(data, { type: 'binary' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet);

            const processedData = jsonData.map((row: any) => {
              const studentId = getNextStudentId();
              return {
                ...row,
                studentId,
                password: generatePassword(),
                isShiftStudent: row.isShiftStudent === 'Yes',
                shiftTime: row.isShiftStudent === 'Yes' ? row.shiftTime : null,
              };
            });

            // Generate PDF with student credentials
            await generateStudentCredentialsPDF(processedData);
            
            onSubmit(processedData);
            setCredentialsDialog({
              visible: true,
              credentials: processedData.map(student => ({
                studentId: student.studentId,
                password: student.password,
                name: student.name,
              })),
            });
            setSnackbarMessage('Students registered successfully. PDF has been generated.');
            setSnackbarVisible(true);
          } catch (error) {
            console.error('Error processing data:', error);
            setSnackbarMessage('Error processing data. Please try again.');
            setSnackbarVisible(true);
          }
        };

        reader.readAsBinaryString(blob);
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      setSnackbarMessage('Error uploading file. Please try again.');
      setSnackbarVisible(true);
    }
  };

  const resetForm = () => {
    setName('');
    setMobile('');
    setEmail('');
    setAddress('');
    setSubscriptionTime('1 Month');
    setIsShiftStudent(false);
    setShiftTime('');
  };

  const renderCredentialsContent = () => {
    const credentials = credentialsDialog.credentials;
    if (Array.isArray(credentials)) {
      return (
        <ScrollView style={styles.credentialsScroll}>
          {credentials.map((cred, index) => (
            <View key={cred.studentId} style={styles.credentialItem}>
              <Text style={styles.credentialName}>{cred.name}</Text>
              <Text style={styles.credentialText}>Student ID: {cred.studentId}</Text>
              <Text style={styles.credentialText}>Password: {cred.password}</Text>
              {index < credentials.length - 1 && <View style={styles.credentialDivider} />}
            </View>
          ))}
        </ScrollView>
      );
    } else {
      return (
        <View style={styles.singleCredential}>
          <Text style={styles.credentialName}>{credentials.name}</Text>
          <Text style={styles.credentialText}>Student ID: {credentials.studentId}</Text>
          <Text style={styles.credentialText}>Password: {credentials.password}</Text>
        </View>
      );
    }
  };

  return (
    <Portal>
      <Modal
        visible={visible}
        onDismiss={onDismiss}
        contentContainerStyle={styles.modalContainer}
      >
        <Text style={styles.title}>Student Registration</Text>
        
        <SegmentedButtons
          value={registrationType}
          onValueChange={setRegistrationType}
          buttons={[
            { value: 'single', label: 'Single Entry' },
            { value: 'bulk', label: 'Bulk Upload' },
          ]}
          style={styles.segmentedButtons}
        />

        {registrationType === 'single' ? (
          <View style={styles.form}>
            <TextInput
              label="Student Name"
              value={name}
              onChangeText={setName}
              style={styles.input}
            />
            <TextInput
              label="Mobile Number"
              value={mobile}
              onChangeText={setMobile}
              keyboardType="phone-pad"
              style={styles.input}
            />
            <TextInput
              label="Email ID"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              style={styles.input}
            />
            <TextInput
              label="Address"
              value={address}
              onChangeText={setAddress}
              multiline
              style={styles.input}
            />
            <List.Accordion
              title={`Subscription Time: ${subscriptionTime}`}
              expanded={subscriptionMenuVisible}
              onPress={() => setSubscriptionMenuVisible(!subscriptionMenuVisible)}
              style={styles.dropdown}
            >
              {subscriptionOptions.map((option) => (
                <List.Item
                  key={option.value}
                  title={option.label}
                  onPress={() => {
                    setSubscriptionTime(option.value);
                    setSubscriptionMenuVisible(false);
                  }}
                />
              ))}
            </List.Accordion>

            <View style={styles.shiftContainer}>
              <View style={styles.shiftSwitch}>
                <Text>Are you a shift attending student?</Text>
                <Switch value={isShiftStudent} onValueChange={setIsShiftStudent} />
              </View>
              {isShiftStudent && (
                <TextInput
                  label="Shift Time (e.g., 9 AM - 1 PM)"
                  value={shiftTime}
                  onChangeText={setShiftTime}
                  style={styles.input}
                />
              )}
            </View>

            <Button
              mode="contained"
              onPress={handleSingleSubmit}
              style={styles.submitButton}
            >
              Submit
            </Button>
          </View>
        ) : (
          <View style={styles.bulkUpload}>
            <Text style={styles.bulkInstructions}>
              Upload Excel or CSV file with columns:
              {'\n'}- Student Name
              {'\n'}- Mobile No.
              {'\n'}- Email ID
              {'\n'}- Address
              {'\n'}- Subscription Time
              {'\n'}- Is Shift Student (Yes/No)
              {'\n'}- Shift Time (Required if Is Shift Student is Yes)
            </Text>
            <Button
              mode="contained"
              onPress={handleBulkUpload}
              style={styles.uploadButton}
            >
              Upload File
            </Button>
          </View>
        )}
      </Modal>

      <Dialog
        visible={credentialsDialog.visible}
        onDismiss={() => setCredentialsDialog({ visible: false, credentials: [] })}
        style={styles.credentialsDialog}
      >
        <Dialog.Title>Student Credentials</Dialog.Title>
        <Dialog.Content>
          {renderCredentialsContent()}
        </Dialog.Content>
        <Dialog.Actions>
          <Button onPress={() => setCredentialsDialog({ visible: false, credentials: [] })}>
            Close
          </Button>
        </Dialog.Actions>
      </Dialog>

      <Snackbar
        visible={snackbarVisible}
        onDismiss={() => setSnackbarVisible(false)}
        duration={3000}
        action={{
          label: 'Close',
          onPress: () => setSnackbarVisible(false),
        }}
      >
        {snackbarMessage}
      </Snackbar>
    </Portal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    backgroundColor: 'white',
    padding: 20,
    margin: 20,
    borderRadius: 8,
    maxHeight: '80%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  segmentedButtons: {
    marginBottom: 20,
  },
  form: {
    gap: 12,
  },
  input: {
    marginBottom: 12,
  },
  dropdown: {
    marginBottom: 12,
    backgroundColor: '#f5f5f5',
    borderRadius: 4,
  },
  shiftContainer: {
    marginBottom: 12,
  },
  shiftSwitch: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  submitButton: {
    marginTop: 20,
  },
  bulkUpload: {
    alignItems: 'center',
    gap: 20,
  },
  bulkInstructions: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'left',
    alignSelf: 'stretch',
  },
  uploadButton: {
    width: '100%',
  },
  credentialsDialog: {
    maxHeight: '80%',
  },
  credentialsScroll: {
    maxHeight: 400,
  },
  credentialItem: {
    paddingVertical: 12,
  },
  credentialDivider: {
    height: 1,
    backgroundColor: '#e0e0e0',
    marginVertical: 8,
  },
  singleCredential: {
    padding: 12,
  },
  credentialName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  credentialText: {
    fontSize: 16,
    marginBottom: 4,
  },
});

export default StudentRegistrationModal;
