import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { Surface, Text } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { RootStackParamList } from '../../App';
import Header from '../common/Header';
import BottomTabNavigator from '../common/BottomTabNavigator';
import StatisticsCards from './St_Home/StatisticsCards';
import QuickActions from './St_Home/QuickActions';
import NearbyLibraries from './St_Home/NearbyLibraries';
import StudyTimeStatistics from './St_Home/StudyTimeStatistics';
import RecentActivities from './St_Home/RecentActivities';

type NavigationProp = StackNavigationProp<RootStackParamList>;

const StudentHome: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState<string | null>(null);

  useEffect(() => {
    checkLoginStatus();
  }, []);

  const checkLoginStatus = async () => {
    try {
      const token = await AsyncStorage.getItem('studentToken');
      const storedUsername = await AsyncStorage.getItem('username');
      setIsLoggedIn(!!token);
      setUsername(storedUsername);
    } catch (error) {
      console.error('Error checking login status:', error);
    }
  };

  const handleLoginPress = () => {
    navigation.navigate('StudentLogin');
  };

  const handleTabChange = (tab: string) => {
    if (!isLoggedIn && tab !== 'home') {
      handleLoginPress();
      return;
    }

    switch (tab) {
      case 'home':
        // Already on home
        break;
      case 'booking':
        navigation.navigate('BookSeat');
        break;
      case 'chat':
        navigation.navigate('StudentChat');
        break;
      case 'profile':
        navigation.navigate('StudentProfile');
        break;
      case 'dashboard':
        navigation.navigate('StudentDashboard');
        break;
    }
  };

  const handleProfilePress = () => {
    if (isLoggedIn) {
      navigation.navigate('StudentProfile');
    } else {
      handleLoginPress();
    }
  };

  const handleNotificationPress = () => {
    if (isLoggedIn) {
      // Handle notifications
    } else {
      handleLoginPress();
    }
  };

  return (
    <View style={styles.container}>
      <Header 
        title="Library Connekto"
        username={username || undefined}
        showWelcome={isLoggedIn}
        onProfilePress={handleProfilePress}
        onNotificationPress={handleNotificationPress}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {!isLoggedIn && (
          <Surface style={styles.welcomeCard}>
            <Text variant="titleMedium" style={styles.welcomeText}>
              Welcome to Library Connekto
            </Text>
            <TouchableOpacity 
              style={styles.loginButton} 
              onPress={handleLoginPress}
            >
              <Text style={styles.loginButtonText}>Login to Access</Text>
            </TouchableOpacity>
          </Surface>
        )}

        <StatisticsCards />
        <QuickActions isLoggedIn={isLoggedIn} onLoginPress={handleLoginPress} />
        <StudyTimeStatistics />
        <NearbyLibraries isLoggedIn={isLoggedIn} onLoginPress={handleLoginPress} />
        <RecentActivities />
      </ScrollView>

      <BottomTabNavigator activeTab="home" onTabChange={handleTabChange} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  welcomeCard: {
    padding: 16,
    marginBottom: 16,
    borderRadius: 12,
    alignItems: 'center',
    backgroundColor: 'white',
  },
  welcomeText: {
    marginBottom: 12,
    color: '#1f2937',
  },
  loginButton: {
    backgroundColor: '#4f46e5',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
});

export default StudentHome;
