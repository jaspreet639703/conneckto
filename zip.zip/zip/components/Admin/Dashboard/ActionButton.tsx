import React from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { Surface, Text } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';

interface ActionButtonProps {
  title: string;
  icon: keyof typeof MaterialIcons.glyphMap;
  backgroundColor: string;
  onPress: () => void;
}

const ActionButton: React.FC<ActionButtonProps> = ({
  title,
  icon,
  backgroundColor,
  onPress
}) => {
  return (
    <TouchableOpacity 
      style={styles.container} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <Surface style={[styles.button, { backgroundColor }]}>
        <MaterialIcons name={icon} size={24} color="#333" />
        <Text style={styles.title}>{title}</Text>
      </Surface>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 8,
  },
  button: {
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 1,
  },
  title: {
    marginTop: 8,
    fontSize: 14,
    color: '#333',
  },
});

export default ActionButton;
