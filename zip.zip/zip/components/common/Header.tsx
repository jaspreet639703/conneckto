import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Appbar, Text, useTheme, Surface } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';

interface HeaderProps {
  title?: string;
  username?: string;
  showWelcome?: boolean;
  onProfilePress?: () => void;
  onNotificationPress?: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  title = "LibraryConneckto", 
  username = "Sandeep Kumar",
  showWelcome = true,
  onProfilePress,
  onNotificationPress
}) => {
  const theme = useTheme();

  return (
    <Surface style={{ elevation: 5 }}>
      <LinearGradient
        colors={['#1E3A8A', '#2563EB']} // Deep blue gradient
        style={{
          height: showWelcome ? 100 : 80, // Adjust height based on welcome message
          justifyContent: 'center',
          paddingHorizontal: 20,
          paddingTop: 20,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          {/* Left Side - Icon & Title */}
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Ionicons name="school" size={28} color="white" />
            <Text
              variant="titleLarge"
              style={{
                color: 'white',
                marginLeft: 12,
                fontWeight: 'bold',
                fontSize: 22,
              }}
            >
              {title}
            </Text>
          </View>

          {/* Right Side - Actions */}
          <View style={{ flexDirection: 'row' }}>
            {onNotificationPress && (
              <Appbar.Action 
                icon="bell" 
                color="white" 
                size={28}
                onPress={onNotificationPress}
              />
            )}
            <Appbar.Action 
              icon="account-circle" 
              color="white" 
              size={28}
              onPress={onProfilePress}
            />
          </View>
        </View>

        {/* Welcome Message */}
        {showWelcome && (
          <Text
            variant="bodyMedium"
            style={{
              color: 'white',
              marginTop: 4,
              marginLeft: 6,
              opacity: 0.9,
            }}
          >
            Welcome, {username} 👋
          </Text>
        )}
      </LinearGradient>
    </Surface>
  );
};

export default Header;
