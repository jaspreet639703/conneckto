import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Surface, Text, List } from 'react-native-paper';

interface Message {
  id: string;
  text: string;
  time: string;
  type: 'info' | 'success' | 'warning';
}

interface AdminMessagesProps {
  messages: Message[];
}

const AdminMessages: React.FC<AdminMessagesProps> = ({ messages }) => {
  const getIconForType = (type: Message['type']) => {
    switch (type) {
      case 'info':
        return 'information';
      case 'success':
        return 'check-circle';
      case 'warning':
        return 'alert';
      default:
        return 'information';
    }
  };

  const getColorForType = (type: Message['type']) => {
    switch (type) {
      case 'info':
        return '#3b82f6';
      case 'success':
        return '#10b981';
      case 'warning':
        return '#f59e0b';
      default:
        return '#3b82f6';
    }
  };

  return (
    <Surface style={styles.container}>
      <Text variant="titleMedium" style={styles.title}>Messages from Admin</Text>
      <View style={styles.messageList}>
        {messages.map((message) => (
          <List.Item
            key={message.id}
            title={message.text}
            description={message.time}
            left={props => (
              <List.Icon 
                {...props} 
                icon={getIconForType(message.type)}
                color={getColorForType(message.type)}
              />
            )}
            style={[
              styles.messageItem,
              { backgroundColor: `${getColorForType(message.type)}10` }
            ]}
          />
        ))}
      </View>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'white',
    marginBottom: 16,
  },
  title: {
    color: '#1f2937',
    marginBottom: 16,
  },
  messageList: {
    gap: 8,
  },
  messageItem: {
    borderRadius: 8,
  },
});

export default AdminMessages;
