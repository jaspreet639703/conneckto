import React, { useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Surface, Text, Button, List, TextInput, Portal, Dialog } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface ScheduleItem {
  id: string;
  title: string;
  time: string;
  completed?: boolean;
}

interface TodayScheduleProps {
  schedule: ScheduleItem[];
}

const TodaySchedule: React.FC<TodayScheduleProps> = ({ schedule: initialSchedule }) => {
  const [schedule, setSchedule] = useState<ScheduleItem[]>(initialSchedule);
  const [modalVisible, setModalVisible] = useState(false);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);

  const generateTimeSlots = () => {
    const slots = [];
    const hours = ['Morning', 'Afternoon', 'Evening', 'Night'];
    const timesByPeriod: Record<string, string[]> = {
      Morning: [],
      Afternoon: [],
      Evening: [],
      Night: []
    };

    for (let hour = 0; hour < 24; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const time = new Date();
        time.setHours(hour, minute);
        const timeString = time.toLocaleTimeString([], { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: true 
        });

        if (hour >= 5 && hour < 12) {
          timesByPeriod['Morning'].push(timeString);
        } else if (hour >= 12 && hour < 17) {
          timesByPeriod['Afternoon'].push(timeString);
        } else if (hour >= 17 && hour < 20) {
          timesByPeriod['Evening'].push(timeString);
        } else {
          timesByPeriod['Night'].push(timeString);
        }
      }
    }

    return hours.map(period => ({
      period,
      times: timesByPeriod[period]
    }));
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setTaskTime(time);
    setShowTimePicker(false);
  };

  const handleAddTask = () => {
    if (taskTitle && taskTime) {
      const newTask: ScheduleItem = {
        id: Date.now().toString(),
        title: taskTitle,
        time: taskTime,
        completed: false,
      };
      
      // Sort tasks by time
      const updatedSchedule = [...schedule, newTask].sort((a, b) => {
        const timeA = new Date(`1970/01/01 ${a.time}`).getTime();
        const timeB = new Date(`1970/01/01 ${b.time}`).getTime();
        return timeA - timeB;
      });
      
      setSchedule(updatedSchedule);
      setTaskTitle('');
      setTaskTime('');
      setSelectedTime(null);
      setModalVisible(false);
    }
  };

  const toggleTaskCompletion = (taskId: string) => {
    setSchedule(schedule.map(task => {
      if (task.id === taskId) {
        const updatedTask = { ...task, completed: !task.completed };
        
        // Move completed tasks to the bottom while maintaining time order among completed and uncompleted tasks separately
        const completedTasks = schedule
          .filter(t => t.id !== taskId && t.completed)
          .concat(task.completed ? [] : [updatedTask]);
        
        const uncompletedTasks = schedule
          .filter(t => t.id !== taskId && !t.completed)
          .concat(task.completed ? [updatedTask] : []);

        // Sort both arrays by time
        const sortByTime = (tasks: ScheduleItem[]) => 
          tasks.sort((a, b) => {
            const timeA = new Date(`1970/01/01 ${a.time}`).getTime();
            const timeB = new Date(`1970/01/01 ${b.time}`).getTime();
            return timeA - timeB;
          });

        setSchedule([...sortByTime(uncompletedTasks), ...sortByTime(completedTasks)]);
        return updatedTask;
      }
      return task;
    }));
  };

  return (
    <>
      <Surface style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Today's Schedule</Text>
          <Button
            mode="contained"
            icon="plus"
            onPress={() => setModalVisible(true)}
            style={styles.addButton}
          >
            Add Task
          </Button>
        </View>
        <View style={styles.scheduleList}>
          {schedule.length === 0 ? (
            <View style={styles.emptyState}>
              <MaterialCommunityIcons 
                name="calendar-check" 
                size={48} 
                color="#6b7280" 
              />
              <Text style={styles.emptyText}>No tasks scheduled for today</Text>
              <Text style={styles.helperText}>
                Add tasks to start planning your day
              </Text>
            </View>
          ) : (
            <>
              {schedule.map((item) => (
                <List.Item
                  key={item.id}
                  title={
                    <Text style={[
                      styles.taskTitle,
                      item.completed && styles.completedTaskTitle
                    ]}>
                      {item.title}
                    </Text>
                  }
                  description={
                    <Text style={[
                      styles.taskTime,
                      item.completed && styles.completedTaskTime
                    ]}>
                      {item.time}
                    </Text>
                  }
                  left={props => (
                    <Button
                      mode="text"
                      onPress={() => toggleTaskCompletion(item.id)}
                      style={styles.checkButton}
                    >
                      <MaterialCommunityIcons 
                        name={item.completed ? "checkbox-marked-circle" : "checkbox-blank-circle-outline"}
                        size={24}
                        color={item.completed ? "#10b981" : "#6b7280"}
                      />
                    </Button>
                  )}
                  right={props => (
                    <MaterialCommunityIcons 
                      {...props}
                      name="clock-outline"
                      size={24}
                      color="#6b7280"
                      style={styles.clockIcon}
                    />
                  )}
                  style={[
                    styles.scheduleItem,
                    item.completed && styles.completedItem
                  ]}
                />
              ))}
            </>
          )}
        </View>
      </Surface>

      <Portal>
        <Dialog visible={modalVisible} onDismiss={() => setModalVisible(false)}>
          <Dialog.Title>Add New Task</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label="Task Title"
              value={taskTitle}
              onChangeText={setTaskTitle}
              mode="outlined"
              style={styles.input}
            />
            
            <Button
              mode="outlined"
              onPress={() => setShowTimePicker(true)}
              style={styles.timeButton}
              icon="clock-outline"
            >
              {taskTime || "Select Task Time"}
            </Button>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setModalVisible(false)}>Cancel</Button>
            <Button onPress={handleAddTask} disabled={!taskTitle || !taskTime}>
              Add Task
            </Button>
          </Dialog.Actions>
        </Dialog>

        <Dialog visible={showTimePicker} onDismiss={() => setShowTimePicker(false)}>
          <Dialog.Title>Select Time</Dialog.Title>
          <Dialog.ScrollArea style={styles.timePickerScrollArea}>
            <ScrollView>
              {generateTimeSlots().map(({ period, times }) => (
                <View key={period} style={styles.periodContainer}>
                  <Text style={styles.periodHeader}>{period}</Text>
                  <View style={styles.timeGrid}>
                    {times.map((time, index) => {
                      const isSelected = selectedTime === time;
                      return (
                        <Button
                          key={index}
                          mode={isSelected ? "contained" : "outlined"}
                          onPress={() => handleTimeSelect(time)}
                          style={[styles.timeOption, isSelected && styles.selectedTime]}
                          labelStyle={isSelected ? styles.selectedTimeText : undefined}
                        >
                          {time}
                        </Button>
                      );
                    })}
                  </View>
                </View>
              ))}
            </ScrollView>
          </Dialog.ScrollArea>
          <Dialog.Actions>
            <Button onPress={() => setShowTimePicker(false)}>Cancel</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'white',
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
  },
  addButton: {
    borderRadius: 20,
  },
  scheduleList: {
    gap: 8,
  },
  scheduleItem: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#f3f4f6',
    marginBottom: 4,
  },
  completedItem: {
    backgroundColor: '#f8fafc',
    borderColor: '#e2e8f0',
    borderWidth: 1,
  },
  taskTitle: {
    fontSize: 16,
    color: '#1f2937',
    fontWeight: '500',
  },
  completedTaskTitle: {
    color: '#94a3b8',
    textDecorationLine: 'line-through',
  },
  taskTime: {
    fontSize: 14,
    color: '#6b7280',
  },
  completedTaskTime: {
    color: '#94a3b8',
  },
  checkButton: {
    margin: 0,
    padding: 0,
  },
  clockIcon: {
    marginRight: 8,
  },
  emptyState: {
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    fontSize: 16,
    color: '#4b5563',
    marginTop: 16,
    marginBottom: 8,
  },
  helperText: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
  },
  input: {
    marginBottom: 16,
  },
  timeButton: {
    marginBottom: 16,
  },
  timePickerScrollArea: {
    maxHeight: 400,
  },
  periodContainer: {
    marginBottom: 16,
  },
  periodHeader: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 8,
    paddingHorizontal: 8,
  },
  timeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    paddingHorizontal: 8,
  },
  timeOption: {
    marginBottom: 4,
    minWidth: '45%',
    borderRadius: 8,
  },
  selectedTime: {
    backgroundColor: '#6366f1',
  },
  selectedTimeText: {
    color: 'white',
  },
});

export default TodaySchedule;
