import React from 'react';
import { StyleSheet } from 'react-native';
import { BottomNavigation as PaperBottomNavigation } from 'react-native-paper';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const styles = StyleSheet.create({
  bar: {
    backgroundColor: 'white',
    elevation: 8,
    height: 64
  }
});

const routes = [
  { 
    key: 'home',
    title: 'Home',
    focusedIcon: 'home',
    unfocusedIcon: 'home-outline'
  },
  { 
    key: 'chat',
    title: 'Chat',
    focusedIcon: 'chat',
    unfocusedIcon: 'chat-outline'
  },
  { 
    key: 'dashboard',
    title: 'Dashboard',
    focusedIcon: 'view-dashboard',
    unfocusedIcon: 'view-dashboard-outline'
  },
  { 
    key: 'profile',
    title: 'Profile',
    focusedIcon: 'account-circle',
    unfocusedIcon: 'account-circle-outline'
  }
];

const BottomNavigation: React.FC<BottomNavigationProps> = ({ activeTab, onTabChange }) => {
  const [index, setIndex] = React.useState(routes.findIndex(tab => tab.key === activeTab));

  return (
    <PaperBottomNavigation
      navigationState={{ index, routes }}
      onIndexChange={(index) => {
        setIndex(index);
        onTabChange(routes[index].key);
      }}
      renderScene={() => null}
      shifting={true}
      barStyle={styles.bar}
      activeColor="#4285F4"
      inactiveColor="#757575"
    />
  );
};

export default BottomNavigation;
