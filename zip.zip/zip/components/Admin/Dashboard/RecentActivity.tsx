import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Surface, Text, Chip } from 'react-native-paper';

interface Activity {
  id: number;
  type: string;
  name: string;
  details: string;
  time: string;
  status: 'completed' | 'pending' | 'cancelled';
}

interface RecentActivityProps {
  activity: Activity;
}

const RecentActivity: React.FC<RecentActivityProps> = ({ activity }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return '#4CAF50';
      case 'pending':
        return '#FFC107';
      case 'cancelled':
        return '#F44336';
      default:
        return '#757575';
    }
  };

  return (
    <Surface style={styles.container} elevation={1}>
      <View style={styles.content}>
        <View style={styles.mainInfo}>
          <Text style={styles.type}>{activity.type}</Text>
          <Text style={styles.name}>{activity.name}</Text>
          <Text style={styles.details}>{activity.details}</Text>
        </View>
        <View style={styles.statusContainer}>
          <Chip 
            style={[styles.status, { backgroundColor: getStatusColor(activity.status) }]}
            textStyle={styles.statusText}
          >
            {activity.status}
          </Chip>
          <Text style={styles.time}>{activity.time}</Text>
        </View>
      </View>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 12,
    backgroundColor: 'white',
  },
  content: {
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  mainInfo: {
    flex: 1,
  },
  type: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  name: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  details: {
    fontSize: 12,
    color: '#888',
    marginTop: 2,
  },
  statusContainer: {
    alignItems: 'flex-end',
  },
  status: {
    marginBottom: 4,
  },
  statusText: {
    color: 'white',
    fontSize: 12,
  },
  time: {
    fontSize: 12,
    color: '#888',
  },
});

export default RecentActivity;
