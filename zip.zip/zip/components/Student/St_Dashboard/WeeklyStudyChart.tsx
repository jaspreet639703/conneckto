import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { Surface, Text } from 'react-native-paper';
import { BarChart } from 'react-native-chart-kit';

interface WeeklyStudyChartProps {
  data: number[];
}

const WeeklyStudyChart: React.FC<WeeklyStudyChartProps> = ({ data }) => {
  const chartData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [{
      data,
    }],
  };

  return (
    <Surface style={styles.container}>
      <Text variant="titleMedium" style={styles.title}>Weekly Study Hours</Text>
      <BarChart
        data={chartData}
        width={Dimensions.get('window').width - 48}
        height={220}
        yAxisLabel=""
        yAxisSuffix=" hrs"
        chartConfig={{
          backgroundColor: '#ffffff',
          backgroundGradientFrom: '#ffffff',
          backgroundGradientTo: '#ffffff',
          decimalPlaces: 1,
          color: (opacity = 1) => `rgba(98, 0, 238, ${opacity})`,
          labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
          style: {
            borderRadius: 16,
          },
          propsForBackgroundLines: {
            strokeWidth: 1,
            stroke: '#e5e7eb',
          },
          propsForLabels: {
            fontSize: 12,
          },
        }}
        style={styles.chart}
        showValuesOnTopOfBars={true}
        fromZero={true}
      />
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'white',
    marginBottom: 16,
  },
  title: {
    marginBottom: 16,
    color: '#1f2937',
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
});

export default WeeklyStudyChart;
