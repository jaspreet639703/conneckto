import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Surface, Text } from 'react-native-paper';

interface DashboardCardProps {
  title: string;
  value: string;
  subtitle: string;
  backgroundColor: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  value,
  subtitle,
  backgroundColor,
}) => {
  const [occupied, total] = value.split('/');

  return (
    <Surface style={[styles.container, { backgroundColor }]} elevation={2}>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.valueContainer}>
        <View style={styles.numberContainer}>
          <Text style={styles.value}>{occupied}</Text>
          <Text style={styles.divider}>/</Text>
          <Text style={styles.total}>{total}</Text>
        </View>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 8,
    padding: 16,
    borderRadius: 12,
    minHeight: 120,
  },
  title: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: 8,
  },
  valueContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  numberContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  value: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
  },
  divider: {
    fontSize: 24,
    color: 'white',
    marginHorizontal: 4,
  },
  total: {
    fontSize: 24,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  subtitle: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
  },
});

export default DashboardCard;
