import React, { useState } from 'react';
import { View, ScrollView, TextInput as RNTextInput, StyleSheet, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { Surface, Text, IconButton, Portal, Modal, Button } from 'react-native-paper';
import * as ImagePicker from 'expo-image-picker';
import Header from '../common/Header';

interface Message {
  id: number;
  text: string;
  time: string;
  isUser: boolean;
  image?: string;
}

const Chat: React.FC = () => {
  const [message, setMessage] = useState('');
  const [showImageOptions, setShowImageOptions] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! How can I help you with the library services today?",
      time: "10:00 AM",
      isUser: false
    },
    {
      id: 2,
      text: "Hi! I need help finding a book about machine learning.",
      time: "10:01 AM",
      isUser: true
    },
    {
      id: 3,
      text: "I can help you with that. Which specific topic in machine learning are you interested in?",
      time: "10:02 AM",
      isUser: false
    }
  ]);

  const handleSend = () => {
    if (message.trim()) {
      const newMessage: Message = {
        id: messages.length + 1,
        text: message,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isUser: true
      };
      setMessages([...messages, newMessage]);
      setMessage('');
    }
  };

  const pickImage = async (useCamera: boolean) => {
    setShowImageOptions(false);
    
    // Request permissions
    if (useCamera) {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        alert('Sorry, we need camera permissions to make this work!');
        return;
      }
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        alert('Sorry, we need camera roll permissions to make this work!');
        return;
      }
    }

    // Launch camera or image picker
    const result = await (useCamera 
      ? ImagePicker.launchCameraAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          quality: 0.8,
          allowsEditing: true,
          aspect: [4, 3],
        })
      : ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          quality: 0.8,
          allowsEditing: true,
          aspect: [4, 3],
        }));

    if (!result.canceled && result.assets[0].uri) {
      const newMessage: Message = {
        id: messages.length + 1,
        text: '',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isUser: true,
        image: result.assets[0].uri
      };
      setMessages([...messages, newMessage]);
    }
  };

  return (
    <View style={styles.container}>
      <Header title="Library Connekto" username="Online" />
      
      <ScrollView style={styles.messagesContainer}>
        {messages.map((msg) => (
          <View
            key={msg.id}
            style={[
              styles.messageWrapper,
              msg.isUser ? styles.userMessageWrapper : styles.botMessageWrapper
            ]}
          >
            <Surface style={[
              styles.messageBubble,
              msg.isUser ? styles.userMessage : styles.botMessage
            ]}>
              {msg.image ? (
                <Image 
                  source={{ uri: msg.image }} 
                  style={styles.messageImage} 
                  resizeMode="cover"
                />
              ) : (
                <Text style={[
                  styles.messageText,
                  msg.isUser ? styles.userMessageText : styles.botMessageText
                ]}>
                  {msg.text}
                </Text>
              )}
              <Text style={[
                styles.timeText,
                msg.isUser ? styles.userTimeText : styles.botTimeText
              ]}>
                {msg.time}
              </Text>
            </Surface>
          </View>
        ))}
      </ScrollView>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.inputContainer}
      >
        <Surface style={styles.inputWrapper}>
          <IconButton
            icon="attachment"
            size={24}
            iconColor="#666"
            onPress={() => {}}
          />
          <RNTextInput
            style={styles.input}
            placeholder="Type your message..."
            value={message}
            onChangeText={setMessage}
            multiline
            onSubmitEditing={handleSend}
          />
          <IconButton
            icon="image"
            size={24}
            iconColor="#666"
            onPress={() => setShowImageOptions(true)}
          />
          <IconButton
            icon="send"
            size={24}
            iconColor={message.trim() ? '#6200ee' : '#666'}
            onPress={handleSend}
          />
        </Surface>
      </KeyboardAvoidingView>

      <Portal>
        <Modal
          visible={showImageOptions}
          onDismiss={() => setShowImageOptions(false)}
          contentContainerStyle={styles.modal}
        >
          <Text style={styles.modalTitle}>Upload Image</Text>
          <Button 
            icon="camera" 
            mode="contained" 
            onPress={() => pickImage(true)}
            style={styles.modalButton}
          >
            Take Photo
          </Button>
          <Button 
            icon="image" 
            mode="contained" 
            onPress={() => pickImage(false)}
            style={styles.modalButton}
          >
            Choose from Gallery
          </Button>
          <Button 
            mode="outlined" 
            onPress={() => setShowImageOptions(false)}
            style={styles.modalButton}
          >
            Cancel
          </Button>
        </Modal>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingBottom: 64
  },
  messagesContainer: {
    flex: 1,
    padding: 16,
    marginBottom: 80
  },
  messageWrapper: {
    marginBottom: 16,
    maxWidth: '80%',
  },
  userMessageWrapper: {
    alignSelf: 'flex-end',
  },
  botMessageWrapper: {
    alignSelf: 'flex-start',
  },
  messageBubble: {
    padding: 12,
    borderRadius: 16,
    elevation: 1,
  },
  userMessage: {
    backgroundColor: '#6200ee',
  },
  botMessage: {
    backgroundColor: 'white',
  },
  messageText: {
    fontSize: 16,
    marginBottom: 4,
  },
  messageImage: {
    width: 200,
    height: 150,
    borderRadius: 8,
  },
  userMessageText: {
    color: 'white',
  },
  botMessageText: {
    color: '#333',
  },
  timeText: {
    fontSize: 12,
    alignSelf: 'flex-end',
  },
  userTimeText: {
    color: 'rgba(255, 255, 255, 0.7)',
  },
  botTimeText: {
    color: 'rgba(0, 0, 0, 0.5)',
  },
  inputContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 64,
    padding: 16,
    backgroundColor: '#f5f5f5',
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    paddingBottom: Platform.OS === 'ios' ? 16 : 16
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 4,
    borderRadius: 24,
    backgroundColor: 'white',
  },
  input: {
    flex: 1,
    marginHorizontal: 8,
    paddingVertical: 8,
    maxHeight: 100,
  },
  modal: {
    backgroundColor: 'white',
    padding: 20,
    margin: 20,
    borderRadius: 8,
  },
  modalTitle: {
    fontSize: 20,
    marginBottom: 20,
    textAlign: 'center',
  },
  modalButton: {
    marginVertical: 5,
  }
});

export default Chat;
