import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { Text } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../App';
import Header from '../../common/Header';
import StudyTimeCard from './StudyTimeCard';
import TasksCompletedCard from './TasksCompletedCard';
import WeeklyStudyChart from './WeeklyStudyChart';
import ExamDetails from './ExamDetails';
import TodaySchedule from './TodaySchedule';
import AdminMessages from './AdminMessages';
import PracticePapers from './PracticePapers';
import BottomTabNavigator from '../../common/BottomTabNavigator';

type NavigationProp = StackNavigationProp<RootStackParamList>;

const mockWeeklyData = [2, 1.5, 3, 2.5, 4, 3.5, 2];
const mockSchedule = [
  { id: '1', title: 'IELTS Reading Practice', time: '09:00 AM', completed: true },
  { id: '2', title: 'GRE Vocabulary Session', time: '11:00 AM' },
  { id: '3', title: 'Mock Test Practice', time: '02:30 PM' },
  { id: '4', title: 'Review Session', time: '04:30 PM' },
];
const mockMessages = [
  {
    id: '1',
    text: 'Your query regarding GRE exam pattern has been resolved.',
    time: '2 hours ago',
    type: 'info' as const,
  },
  {
    id: '2',
    text: 'New study materials have been added to your IELTS course.',
    time: 'Yesterday',
    type: 'success' as const,
  },
  {
    id: '3',
    text: 'Important announcement: Mock test schedule updated for next week.',
    time: '2 days ago',
    type: 'warning' as const,
  },
];

const Stu_Dashboard: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const [showNotifications, setShowNotifications] = React.useState(false);
  const [selectedExam, setSelectedExam] = React.useState("");
  const [studyHours, setStudyHours] = React.useState(0);
  const [showScheduleModal, setShowScheduleModal] = React.useState(false);
  const [scheduleTime, setScheduleTime] = React.useState("");
  const [scheduleTask, setScheduleTask] = React.useState("");
  const [examDate, setExamDate] = React.useState("");
  const studentName = "Alexander Mitchell";

  const handleTabChange = (tab: string) => {
    switch (tab) {
      case 'home':
        navigation.navigate('StudentHome');
        break;
      case 'booking':
        navigation.navigate('BookSeat');
        break;
      case 'chat':
        navigation.navigate('StudentChat');
        break;
      case 'profile':
        navigation.navigate('StudentProfile');
        break;
      case 'dashboard':
        // Already on dashboard
        break;
    }
  };

  const handleScheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowScheduleModal(false);
  };

  return (
    <View style={styles.container}>
      <Header
        title="Dashboard"
        showWelcome={true}
        username="Alexander Mitchell"
      />
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Text variant="titleLarge" style={styles.welcomeText}>
          Welcome back, Alexander Mitchell!
        </Text>
        <Text variant="bodyMedium" style={styles.subText}>
          Track your exam preparation progress
        </Text>

        <View style={styles.statsContainer}>
          <StudyTimeCard hours={4.5} />
          <TasksCompletedCard completed={3} total={6} />
        </View>

        <WeeklyStudyChart data={mockWeeklyData} />
        <ExamDetails />
        <TodaySchedule schedule={mockSchedule} />
        <AdminMessages messages={mockMessages} />
        <PracticePapers />
      </ScrollView>

      <BottomTabNavigator activeTab="dashboard" onTabChange={handleTabChange} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  welcomeText: {
    color: '#1f2937',
    marginBottom: 4,
  },
  subText: {
    color: '#6b7280',
    marginBottom: 24,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
  },
});

export default Stu_Dashboard;
