import React, { useState, useMemo } from 'react';
import { View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Provider as PaperProvider, DefaultTheme } from 'react-native-paper';
import UseRole from './components/UseRole';
import AdminLogin from './components/Admin/Adminlogin';
import AdminDetails from './components/Admin/Admin_Details';
import Home from './components/Admin/Home';
import Profile from './components/Admin/Profile/Profile';
import Chat from './components/chat/chat';
import Dashboard from './components/Admin/Dashboard/dashboard';
import BottomNavigation from './components/common/BottomNavigation';
import StudentManagement from './components/Admin/Dashboard/Student_management';
import SeatManagement from './components/Admin/Dashboard/Seat management';
import StudentAttendance from './components/Admin/Dashboard/St_Attendance';
import Analytics from './components/Admin/Dashboard/Analytics';
import Refer from './components/Admin/Refer/Refer';
import StudentLogin from './components/Student/Student_Login';
import StudentHome from './components/Student/Student_Home';
import Stud_Chat from './components/Student/Stud_Chat';
import Stud_Profile from './components/Student/Stud_Profile';
import BookSeat from './components/Student/BookSeat';
import StudentDashboard from './components/Student/St_Dashboard/Stu_Dashboard';

export type RootStackParamList = {
  MainDashboard: undefined;
  StudentManagement: undefined;
  SeatManagement: undefined;
  StudentAttendance: undefined;
  Analytics: undefined;
  Profile: undefined;
  Refer: undefined;
  AdminLogin: undefined;
  StudentLogin: undefined;
  StudentHome: undefined;
  UseRole: undefined;
  AdminDetails: undefined;
  StudentChat: undefined;
  StudentProfile: undefined;
  BookSeat: undefined;
  Dashboard: undefined;
  StudentDashboard: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();
const StudentTab = createBottomTabNavigator();

const StudentTabNavigator = () => {
  return (
    <StudentTab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { display: 'none' }, // Hide default tab bar since we're using custom
        presentation: 'card'
      }}
    >
      <StudentTab.Screen name="StudentHomeTab" component={StudentHome} />
      <StudentTab.Screen name="BookSeatTab" component={BookSeat} />
      <StudentTab.Screen name="StudentDashboardTab" component={StudentDashboard} />
      <StudentTab.Screen name="StudentChatTab" component={Stud_Chat} />
      <StudentTab.Screen name="StudentProfileTab" component={Stud_Profile} />
    </StudentTab.Navigator>
  );
};

interface LibraryDetails {
  libraryName: string;
  mobileNo: string;
  address: string;
  totalSeats: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#6200ee',
    accent: '#03dac4',
  },
};

// Create AuthContext
export const AuthContext = React.createContext<{
  setSelectedRole: (role: string | null) => void;
  setIsLoggedIn: (value: boolean) => void;
  setShowHome: (value: boolean) => void;
}>({
  setSelectedRole: () => {},
  setIsLoggedIn: () => {},
  setShowHome: () => {}
});

const App = () => {
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showHome, setShowHome] = useState(false);
  const [showAdminDetails, setShowAdminDetails] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [libraryDetails, setLibraryDetails] = useState<LibraryDetails | null>(null);

  const authContext = useMemo(() => ({
    setSelectedRole,
    setIsLoggedIn,
    setShowHome
  }), []);

  const handleRoleSelect = (role: string) => {
    setSelectedRole(role);
  };

  const handleBack = () => {
    setSelectedRole(null);
    setIsLoggedIn(false);
    setShowHome(false);
    setShowAdminDetails(false);
  };

  const handleLoginSuccess = () => {
    if (selectedRole === 'admin') {
      setIsLoggedIn(true);
      setShowAdminDetails(true);
    } else {
      setIsLoggedIn(true);
      setShowHome(true);
    }
  };

  const handleSaveDetails = (details: LibraryDetails) => {
    setLibraryDetails(details);
    setShowAdminDetails(false);
    setShowHome(true);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const renderMainContent = () => {
    switch (activeTab) {
      case 'home':
        return <Home />;
      case 'chat':
        return <Chat />;
      case 'dashboard':
        return <Dashboard />;
      case 'profile':
        return <Profile />;
      default:
        return <Home />;
    }
  };

  return (
    <PaperProvider theme={theme}>
      <AuthContext.Provider value={authContext}>
        <NavigationContainer>
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
            }}
          >
            {!selectedRole ? (
              <Stack.Screen name="UseRole">
                {() => <UseRole onRoleSelect={handleRoleSelect} />}
              </Stack.Screen>
            ) : selectedRole === 'student' ? (
              <>
                <Stack.Screen 
                  name="StudentHome"
                  component={StudentTabNavigator}
                  options={{
                    headerShown: false,
                    presentation: 'card',
                    cardStyleInterpolator: ({ current, layouts }) => ({
                      cardStyle: {
                        transform: [
                          {
                            translateX: current.progress.interpolate({
                              inputRange: [0, 1],
                              outputRange: [layouts.screen.width, 0],
                            }),
                          },
                        ],
                      },
                    }),
                  }}
                />
                <Stack.Screen 
                  name="StudentLogin"
                  options={{
                    headerShown: false,
                    presentation: 'card',
                    cardStyleInterpolator: ({ current, layouts }) => ({
                      cardStyle: {
                        transform: [
                          {
                            translateX: current.progress.interpolate({
                              inputRange: [0, 1],
                              outputRange: [layouts.screen.width, 0],
                            }),
                          },
                        ],
                      },
                    }),
                  }}
                >
                  {() => (
                    <StudentLogin 
                      onLoginSuccess={handleLoginSuccess}
                      onBack={handleBack}
                    />
                  )}
                </Stack.Screen>
                <Stack.Screen 
                  name="StudentChat" 
                  component={Stud_Chat}
                  options={{
                    headerShown: false
                  }}
                />
                <Stack.Screen 
                  name="StudentProfile" 
                  component={Stud_Profile}
                  options={{
                    headerShown: false
                  }}
                />
                <Stack.Screen 
                  name="BookSeat" 
                  component={BookSeat}
                  options={{
                    headerShown: false
                  }}
                />
                <Stack.Screen 
                  name="StudentDashboard" 
                  component={StudentDashboard}
                  options={{
                    headerShown: false
                  }}
                />
                <Stack.Screen 
                  name="Dashboard" 
                  component={Dashboard}
                  options={{
                    headerShown: false
                  }}
                />
                <Stack.Screen 
                  name="Refer" 
                  component={Refer}
                  options={{
                    headerShown: true,
                    title: 'Refer a Friend'
                  }}
                />
              </>
            ) : (
              <>
                {!isLoggedIn ? (
                  <Stack.Screen name="AdminLogin">
                    {() => (
                      <AdminLogin 
                        onLoginSuccess={handleLoginSuccess}
                        onBack={handleBack}
                      />
                    )}
                  </Stack.Screen>
                ) : showAdminDetails ? (
                  <Stack.Screen name="AdminDetails">
                    {() => (
                      <AdminDetails 
                        onBack={handleBack}
                        onSave={handleSaveDetails}
                      />
                    )}
                  </Stack.Screen>
                ) : (
                  <>
                    <Stack.Screen name="MainDashboard">
                      {() => (
                        <>
                          {renderMainContent()}
                          <View style={{ 
                            position: 'absolute', 
                            left: 0, 
                            right: 0, 
                            bottom: 0, 
                            backgroundColor: 'white',
                            elevation: 8,
                            shadowColor: '#000',
                            shadowOffset: { width: 0, height: -2 },
                            shadowOpacity: 0.1,
                            shadowRadius: 4,
                            zIndex: 1000
                          }}>
                            <BottomNavigation 
                              activeTab={activeTab} 
                              onTabChange={handleTabChange} 
                            />
                          </View>
                        </>
                      )}
                    </Stack.Screen>
                    <Stack.Screen name="StudentManagement" component={StudentManagement} />
                    <Stack.Screen name="SeatManagement" component={SeatManagement} />
                    <Stack.Screen name="StudentAttendance" component={StudentAttendance} />
                    <Stack.Screen name="Analytics" component={Analytics} />
                    <Stack.Screen name="Profile" component={Profile} />
                    <Stack.Screen name="Refer" component={Refer} />
                  </>
                )}
              </>
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </AuthContext.Provider>
    </PaperProvider>
  );
};

export default App;
