import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Modal, StyleSheet, Platform, Alert } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { Picker } from '@react-native-picker/picker';
import { Ionicons } from '@expo/vector-icons';
import Header from '../common/Header';
import * as Location from 'expo-location';

interface Library {
  id: string;
  name: string;
  address: string;
  distance?: number;
  coordinates: {
    lat: number;
    lng: number;
  };
}

// Define the navigation type
type RootStackParamList = {
  StudentHome: undefined;
  StudentProfile: undefined;
  BookSeat: undefined;
};

type BookSeatScreenNavigationProp = StackNavigationProp<RootStackParamList>;

const BookSeat: React.FC = () => {
  const navigation = useNavigation<BookSeatScreenNavigationProp>();
  const [formData, setFormData] = useState({
    name: "",
    mobile: "",
    email: "",
    address: "",
    subscription: "1",
    selectedLibrary: "",
  });

  const [showLibrarySelector, setShowLibrarySelector] = useState(false);
  const [userLocation, setUserLocation] = useState<{
    lat: number;
    lng: number;
  } | null>(null);
  const [libraries] = useState<Library[]>([
    {
      id: "lib1",
      name: "Central Library Delhi",
      address: "Connaught Place, New Delhi",
      coordinates: { lat: 28.6329, lng: 77.2195 },
    },
    {
      id: "lib2",
      name: "Mumbai Public Library",
      address: "Colaba, Mumbai",
      coordinates: { lat: 18.922, lng: 72.8347 },
    },
    {
      id: "lib3",
      name: "Bangalore State Library",
      address: "MG Road, Bangalore",
      coordinates: { lat: 12.9716, lng: 77.5946 },
    },
    {
      id: "lib4",
      name: "Chennai Library Hub",
      address: "Anna Nagar, Chennai",
      coordinates: { lat: 13.0827, lng: 80.2707 },
    },
  ]);
  const [nearestLibraries, setNearestLibraries] = useState<Library[]>([]);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [ticketNumber, setTicketNumber] = useState("");
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [loading, setLoading] = useState(false);

  const subscriptionOptions = [
    { value: "1", label: "1 Month", price: 29.99 },
    { value: "3", label: "3 Months", price: 79.99 },
    { value: "6", label: "6 Months", price: 149.99 },
    { value: "12", label: "1 Year", price: 279.99 },
  ];

  const calculateDistance = (
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number,
  ) => {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          Alert.alert('Permission Denied', 'Please allow location access to find nearby libraries.');
          return;
        }

        setLoading(true);
        const location = await Location.getCurrentPositionAsync({});
        
        const librariesWithDistance = libraries
          .map((library) => ({
            ...library,
            distance: calculateDistance(
              location.coords.latitude,
              location.coords.longitude,
              library.coordinates.lat,
              library.coordinates.lng,
            ),
          }))
          .sort((a, b) => (a.distance || 0) - (b.distance || 0));

        setNearestLibraries(librariesWithDistance);
      } catch (error) {
        Alert.alert('Error', 'Failed to get location. Please try again.');
        console.error(error);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.selectedLibrary)
      newErrors.library = "Please select a library";
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.mobile.trim()) newErrors.mobile = "Mobile number is required";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!formData.address.trim()) newErrors.address = "Address is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      const randomTicket =
        "LIB" + Math.random().toString(36).substr(2, 9).toUpperCase();
      setTicketNumber(randomTicket);
      setShowConfirmation(true);
    }
  };

  return (
    <View style={styles.container}>
      <Header 
        title="Book Your Study Space" 
        showWelcome={false}
        onProfilePress={() => navigation.navigate('StudentProfile')}
      />
      
      <ScrollView style={styles.scrollView}>
        {showLibrarySelector ? (
          <View style={styles.librarySelector}>
            <View style={styles.librarySelectorHeader}>
              <Text style={styles.sectionTitle}>Select Library</Text>
              <TouchableOpacity onPress={() => setShowLibrarySelector(false)}>
                <Ionicons name="close" size={24} color="#666" />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              onPress={() => {
                setLoading(true);
                Location.getCurrentPositionAsync({}).then((location) => {
                  const librariesWithDistance = libraries
                    .map((library) => ({
                      ...library,
                      distance: calculateDistance(
                        location.coords.latitude,
                        location.coords.longitude,
                        library.coordinates.lat,
                        library.coordinates.lng,
                      ),
                    }))
                    .sort((a, b) => (a.distance || 0) - (b.distance || 0));

                  setNearestLibraries(librariesWithDistance);
                  setLoading(false);
                }).catch((error) => {
                  Alert.alert('Error', 'Failed to get location. Please try again.');
                  console.error(error);
                  setLoading(false);
                });
              }}
              style={styles.findLibrariesButton}
            >
              <Ionicons name="location" size={20} color="#fff" />
              <Text style={styles.buttonText}>Find Nearest Libraries</Text>
            </TouchableOpacity>

            {loading ? (
              <Text>Finding nearest libraries...</Text>
            ) : (
              nearestLibraries.map((library) => (
                <TouchableOpacity
                  key={library.id}
                  onPress={() => {
                    setFormData((prev) => ({
                      ...prev,
                      selectedLibrary: library.id,
                    }));
                    setShowLibrarySelector(false);
                  }}
                  style={[
                    styles.libraryItem,
                    formData.selectedLibrary === library.id && styles.selectedLibrary,
                  ]}
                >
                  <View>
                    <Text style={styles.libraryName}>{library.name}</Text>
                    <Text style={styles.libraryAddress}>{library.address}</Text>
                  </View>
                  {library.distance && (
                    <Text style={styles.distance}>
                      {library.distance.toFixed(1)} km
                    </Text>
                  )}
                </TouchableOpacity>
              ))
            )}
          </View>
        ) : (
          <View style={styles.formContainer}>
            <TouchableOpacity
              onPress={() => {
                setShowLibrarySelector(true);
                if (nearestLibraries.length === 0) {
                  setNearestLibraries(libraries);
                }
              }}
              style={styles.librarySelector}
            >
              <View style={styles.libraryButton}>
                <Ionicons name="library" size={24} color="#6B46C1" />
                <Text style={styles.libraryButtonText}>
                  {formData.selectedLibrary
                    ? libraries.find((l) => l.id === formData.selectedLibrary)?.name
                    : "Select Library"}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={24} color="#666" />
            </TouchableOpacity>
            {errors.library && (
              <Text style={styles.errorText}>{errors.library}</Text>
            )}

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Full Name</Text>
              <TextInput
                style={styles.input}
                value={formData.name}
                onChangeText={(text) =>
                  setFormData((prev) => ({ ...prev, name: text }))
                }
                placeholder="Enter your full name"
              />
              {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Mobile Number</Text>
              <View style={styles.phoneInput}>
                <View style={styles.countryCode}>
                  <Text>+1</Text>
                </View>
                <TextInput
                  style={styles.phoneNumber}
                  value={formData.mobile}
                  onChangeText={(text) =>
                    setFormData((prev) => ({ ...prev, mobile: text }))
                  }
                  placeholder="Enter mobile number"
                  keyboardType="phone-pad"
                />
              </View>
              {errors.mobile && (
                <Text style={styles.errorText}>{errors.mobile}</Text>
              )}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email Address</Text>
              <TextInput
                style={styles.input}
                value={formData.email}
                onChangeText={(text) =>
                  setFormData((prev) => ({ ...prev, email: text }))
                }
                placeholder="Enter email address"
                keyboardType="email-address"
                autoCapitalize="none"
              />
              {errors.email && (
                <Text style={styles.errorText}>{errors.email}</Text>
              )}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Address</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.address}
                onChangeText={(text) =>
                  setFormData((prev) => ({ ...prev, address: text }))
                }
                placeholder="Enter your address"
                multiline
                numberOfLines={3}
              />
              {errors.address && (
                <Text style={styles.errorText}>{errors.address}</Text>
              )}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Select Subscription Period</Text>
              <View style={styles.pickerContainer}>
                <Picker
                  selectedValue={formData.subscription}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, subscription: value }))
                  }
                  style={styles.picker}
                >
                  {subscriptionOptions.map((option) => (
                    <Picker.Item
                      key={option.value}
                      label={`${option.label} - $${option.price}`}
                      value={option.value}
                    />
                  ))}
                </Picker>
              </View>
            </View>

            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleSubmit}
            >
              <Text style={styles.submitButtonText}>Book Now</Text>
            </TouchableOpacity>
          </View>
        )}

        <Modal
          visible={showConfirmation}
          transparent
          animationType="fade"
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Ionicons name="checkmark-circle" size={60} color="#10B981" />
              <Text style={styles.modalTitle}>Booking Confirmed!</Text>
              <Text style={styles.modalText}>Your ticket number is:</Text>
              <View style={styles.ticketContainer}>
                <Text style={styles.ticketNumber}>{ticketNumber}</Text>
              </View>
              <Text style={styles.modalText}>Please wait for the seat confirmation by Study Library Admin.</Text>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setShowConfirmation(false);
                  navigation.navigate('StudentHome');
                }}
              >
                <Text style={styles.modalButtonText}>Done</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  librarySelector: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  librarySelectorHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
  },
  findLibrariesButton: {
    backgroundColor: '#6B46C1',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  buttonText: {
    color: '#fff',
    marginLeft: 8,
    fontSize: 16,
    fontWeight: '500',
  },
  libraryItem: {
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    marginBottom: 8,
  },
  selectedLibrary: {
    borderColor: '#6B46C1',
    backgroundColor: '#F3F4F6',
  },
  libraryName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1F2937',
  },
  libraryAddress: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
  },
  distance: {
    fontSize: 14,
    color: '#6B46C1',
    fontWeight: '500',
  },
  formContainer: {
    flex: 1,
  },
  libraryButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  libraryButtonText: {
    marginLeft: 8,
    fontSize: 16,
    color: '#1F2937',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#4B5563',
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  phoneInput: {
    flexDirection: 'row',
  },
  countryCode: {
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  phoneNumber: {
    flex: 1,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderLeftWidth: 0,
    borderColor: '#E5E7EB',
    borderTopRightRadius: 8,
    borderBottomRightRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  pickerContainer: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    overflow: 'hidden',
  },
  picker: {
    height: 50,
  },
  errorText: {
    color: '#EF4444',
    fontSize: 12,
    marginTop: 4,
  },
  submitButton: {
    backgroundColor: '#6B46C1',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 32,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    width: '90%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#1F2937',
    marginTop: 16,
    marginBottom: 8,
  },
  modalText: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 16,
  },
  ticketContainer: {
    backgroundColor: '#F3F4F6',
    padding: 16,
    borderRadius: 8,
    marginBottom: 24,
  },
  ticketNumber: {
    fontSize: 20,
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    fontWeight: '600',
    color: '#6B46C1',
  },
  modalButton: {
    backgroundColor: '#6B46C1',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default BookSeat;
